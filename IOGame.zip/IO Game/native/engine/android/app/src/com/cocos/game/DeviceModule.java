package com.cocos.game;

/**
 * Created by liwenlong on 2020/8/28.
 */


import java.io.FileNotFoundException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.provider.Settings;
import android.os.Vibrator;
import com.cocos.lib.CocosJavascriptJavaBridge;
import com.cocos.lib.CocosActivity;
import com.cocos.lib.CocosHelper;
import android.provider.MediaStore;

public class DeviceModule {
    private static Context context = null;
    private static AppActivity app = null;
    private static float batteryLevel = 1;
	public static String IMEI = "";
	public static String copyStr = "";
    public static void setContext(Context context)
    {
        DeviceModule.context = context;
        DeviceModule.app = (AppActivity) context;
    }

	public static void runJsCode(final String code) {
		// 一定要在 GL 线程中执行
		CocosHelper.runOnGameThread(new Runnable() {
			@Override
			public void run() {
				CocosJavascriptJavaBridge.evalString(code);
			}
		});
	}

	public static String getDeviceName() {
		assert(Build.MODEL != null);
		return Build.MODEL;
	}

	public static String getSystemVersion() {
    	return android.os.Build.VERSION.RELEASE;
	}

	public static String getUserToken() {
		return md5(getAndroidID());
	}

	public static String getAndroidID() {
		String androidID = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
		return androidID;
	}

	public static String getAppVersion() {
		try
		{
			PackageInfo info = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
			assert(info.versionName != null);
			return info.versionName;
		} catch (NameNotFoundException e)
		{
			e.printStackTrace();
		}
		return "";
	}

	public static String getAppVerCode() {
		PackageManager packageManager = context.getPackageManager();
		PackageInfo packageInfo;
		String versionCode="";
		try {
			packageInfo=packageManager.getPackageInfo(context.getPackageName(),0);
			versionCode=packageInfo.versionCode+"";
		} catch (PackageManager.NameNotFoundException e)
		{
			e.printStackTrace();
		}
		return versionCode;
	}

	public static String getMacAddress() {
		WifiManager wifi = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
		WifiInfo info = wifi.getConnectionInfo();
		String macAddr = info.getMacAddress();
		return macAddr;
	}

	public static float getBatteryLevel() {
		IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(Intent.ACTION_BATTERY_CHANGED);
		context.registerReceiver(new BroadcastReceiver() {
			@Override
			public void onReceive(Context context, Intent intent) {
				String action = intent.getAction();
				if (action.equals(Intent.ACTION_BATTERY_CHANGED)) {
					int level = intent.getIntExtra("level", 0);
					int scale = intent.getIntExtra("scale", 0);
					Log.d("test", level + " --- " + scale);
					if (scale != 0) {
						batteryLevel = ((float) level) / scale;
						if (batteryLevel < 0) {
							batteryLevel = 0;
						} else if (batteryLevel > 1) {
							batteryLevel = 1;
						}
					} else {
						batteryLevel = 0;
					}
				}
			}
		}, intentFilter);
		return batteryLevel;
	}

	public static String getNetworkStatus() {
		ConnectivityManager connMgr = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();

		String retstring = "none";
		if (networkInfo == null) {
			return retstring;
		}
		int nType = networkInfo.getType();
		if (nType == ConnectivityManager.TYPE_MOBILE) {
			retstring = "wwan";
		} else if (nType == ConnectivityManager.TYPE_WIFI) {
			retstring = "wifi";
		}
		return retstring;
	}

    public static String md5(String s) {
		try {
			// Create MD5 Hash
			MessageDigest digest = java.security.MessageDigest
					.getInstance("MD5");
			digest.update(s.getBytes());
			byte messageDigest[] = digest.digest();
			// Create HEX String
			StringBuffer hexString = new StringBuffer();
			for (int i = 0; i < messageDigest.length; i++) {
				String sTmp = Integer.toHexString(0xFF & messageDigest[i]);
				switch (sTmp.length()) {
				case 0:
					hexString.append("00");
					break;
				case 1:
					hexString.append("0");
					hexString.append(sTmp);
					break;
				default:
					hexString.append(sTmp);
					break;
				}
			}
			return hexString.toString().toLowerCase();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return "";
	}

	public static void mobileShake(int timeMs) {
		Vibrator vibrator = (Vibrator)context.getSystemService(Context.VIBRATOR_SERVICE);
		vibrator.vibrate(timeMs);//震半秒钟
	}

	public static void copyToClipboard(final String text) {
        try
        {
            Runnable runnable = new Runnable() {
                public void run() {
                    ClipboardManager clipboard = (ClipboardManager) app.getSystemService(Context.CLIPBOARD_SERVICE);
                    ClipData clip = ClipData.newPlainText("Copied Text", text);
                    clipboard.setPrimaryClip(clip);
                }
            };
            app.runOnUiThread(runnable);

        }catch(Exception e){
            Log.d("Cocos","copyToClipboard error");
            e.printStackTrace();
        }
	}

	public static void getClipContent () {
        try {
            app.runOnUiThread(new Runnable() {

                @Override
                public void run() {
                    ClipboardManager clipboard = (ClipboardManager)app.getSystemService(Context.CLIPBOARD_SERVICE);
                    ClipData clipData = clipboard.getPrimaryClip();
                    if (clipData != null && clipData.getItemCount() > 0) {
                        CharSequence text = clipData.getItemAt(0).getText();
                        if (text != null) {
							String textStr = text.toString();
							String code = "clipCallback( '";
							code += textStr;
							code += "');";
							DeviceModule.runJsCode(code);
						}
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
	}

}
