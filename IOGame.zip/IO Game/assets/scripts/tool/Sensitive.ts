
import { resources } from 'cc';

import SensitiveWords from "js-sensitivewords";

/**
 * 敏感词过滤类
 */
export class Sensitive {

    /**
     * 敏感词过滤器
     */
    public static instance: Sensitive;

    // private sensitiveList: string[] = [];

    private sw: any = undefined;

    constructor() {
        Sensitive.instance = this;

        this.sw = SensitiveWords;

        // 加载敏感词库
        resources.load("json/sensitive_word", (err: Error, data: any) => {
            // console.log(data.json.data);
            // this.sensitiveList = data.json.data;
            this.sw.addWords(data.json.data);
        })
    }

    /**
     * 敏感词过滤
     * @param str 字符串
     * @returns 过滤后的字符串
     */
    public filterSensitive(str: string): string {

        let filterText: string = this.sw.replaceDfa(str, "*", false);

        return filterText;
    }
}