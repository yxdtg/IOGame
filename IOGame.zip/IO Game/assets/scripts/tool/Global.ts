import { DeviceModule } from './DeviceModule';

//获取复制内容回调(原生层的全局回调)
window["clipCallback"] = function clipCallback(text) {
    // console.log("获取复制内容回调(原生层的全局回调)");
    if (DeviceModule._clipCallback) {
        DeviceModule._clipCallback(text);
    }
}
