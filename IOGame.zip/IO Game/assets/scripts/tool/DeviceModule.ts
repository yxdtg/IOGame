import { director, sys } from "cc";


export class DeviceModule {
    private AndroidClassPath = 'com/cocos/game/DeviceModule';    //需要修改为DeviceModule对应的位置

    private static instance: DeviceModule;
    public static _clipCallback: Function;
    //获取这个单例
    static getInstance() {
        if (!this.instance) {
            this.instance = new DeviceModule();
        }
        return this.instance;
    }

    //格式化时间戳
    strTimestamp() {
        var time = new Date();
        var date = time.getFullYear() + "-" +
            (time.getMonth() + 1) + "-" +
            (time.getDate()) + " ";
        var timeStr = '';
        if (time.getHours() < 10) {
            timeStr += '0';
        }
        timeStr += time.getHours() + ":";
        if (time.getMinutes() < 10) {
            timeStr += '0';
        }
        timeStr += time.getMinutes() + ":";
        if (time.getSeconds() < 10) {
            timeStr += '0';
        }
        timeStr += time.getSeconds();
        return date + timeStr;
    }

    mobileShake(timeMs) {
        if (sys.os === sys.OS.ANDROID) {
            return jsb.reflection.callStaticMethod(
                this.AndroidClassPath,
                "mobileShake",
                "(I)V", timeMs);
        } else if (sys.os === sys.OS.IOS) {
            return jsb.reflection.callStaticMethod("DeviceModule", "mobileShake:", timeMs);
        }
    }

    //复制文字到粘贴板
    copyToClipboard(copyText) {
        if (sys.os === sys.OS.ANDROID) {
            return jsb.reflection.callStaticMethod(
                this.AndroidClassPath,
                "copyToClipboard",
                "(Ljava/lang/String;)V",
                copyText);
        } else if (sys.os === sys.OS.IOS) {
            return jsb.reflection.callStaticMethod("DeviceModule", "copyToClipboard:", copyText);
        }
    }

    //获取粘贴板文字，安卓只能异步回调 否则某些机型会闪退
    getClipContent(callback) {
        DeviceModule._clipCallback = callback;
        if (sys.os === sys.OS.ANDROID) {
            jsb.reflection.callStaticMethod(
                this.AndroidClassPath,
                "getClipContent",
                "()V");
        } else if (sys.os === sys.OS.IOS) {
            // let text = jsb.reflection.callStaticMethod("DeviceModule", "getClipContent");
            // callback(text);
        }
    }

    //获取复制内容回调
    clipCallback(text) {
        if (DeviceModule._clipCallback) {
            DeviceModule._clipCallback(text);
        }
    }

}
