
export class lMessage {

    public id: number;

    public type: number;

    public value: string;

    public count: number;

    constructor(id: number, type: number, value: string) {
        this.id = id;
        this.type = type;
        this.value = value;
        this.count = 0;
    }

}