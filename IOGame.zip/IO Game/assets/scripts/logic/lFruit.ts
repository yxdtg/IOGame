
export class lFruit {

    public id: number;

    public type: number;

    public name: string;

    public x: number;

    public y: number;

    public width: number;

    public height: number;

    constructor(id: number, type: number, x: number, y: number, width: number, height: number, name?: string) {
        this.id = id;
        this.type = type;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

}