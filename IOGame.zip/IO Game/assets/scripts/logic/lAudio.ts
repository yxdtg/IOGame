
/**
 * 音频类
 */
export class lAudio {

    public id: number;
    public name: string;

    public x: number;
    public y: number;

    public count: number;

    constructor(id: number, name: string, x: number, y: number) {
        this.id = id;
        this.name = name;
        this.x = x;
        this.y = y;
        this.count = 0;
    }

}