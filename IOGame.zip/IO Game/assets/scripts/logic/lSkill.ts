
/**
 * 技能类
 */
export class lSkill {

    /**
     * 技能名称
     */
    public name: string;
    /**
     * 技能冷却时间
     */
    public interval: number;
    /**
     * 技能最大冷却时间
     */
    public intervalMax: number;
    /**
     * 技能消耗魔法值
     */
    public mp: number;
    /**
     * 技能介绍内容
     */
    public text: string;
    /**
     * 是否是主动技能
     */
    public isInput: boolean;

    constructor(name: string, intervalMax: number, mp: number, isInput: boolean, text: string) {
        this.name = name;
        this.interval = 0;
        this.intervalMax = intervalMax;
        this.mp = mp;
        this.isInput = isInput;
        this.text = text;
    }
}
