
export class lLabel {

    public id: number;

    public value: string;
    public color: number[];
    public x: number;
    public y: number;

    public scale: number;
    public count: number;

    constructor(id: number, value: string, color: number[], x: number, y: number) {
        this.id = id;
        this.value = value;
        this.color = color;
        this.x = x;
        this.y = y;
        this.scale = 1;
        this.count = 0;
    }

}