import { Logic } from "../scene/Logic";
import { lSkill } from "./lSkill";

/**
 * 技能计数类
 */
type SkillCount = {
    name: string,
    count: number,
};

export class lPlayer {

    /**
     * 玩家id
     */
    public id: number;

    /**
     * 玩家昵称
     */
    public name: string;

    /**
     * 是否是机器人
     */
    public isRobot: boolean;

    /**
     * 角色id
     */
    public userId: number;

    /**
     * 队伍id
     */
    public teamId: number;

    /**
     * 玩家x坐标
     */
    public x: number;

    /**
     * 玩家y坐标
     */
    public y: number;

    /**
     * 玩家是否在攻击
     */
    public isAttack: boolean;

    /**
     * 玩家攻击力
     */
    public attack: number;

    public attackInterval: number;
    public attackMaxInterval: number;

    /**
     * 玩家经验值
     */
    public experience: number;

    /**
     * 玩家最大经验值
     */
    public experienceMax: number;

    /**
     * 玩家等级
     */
    public rank: number;

    /**
     * 玩家最大等级
     */
    public rankMax: number;

    /**
     * 玩家血量
     */
    public hp: number;

    /**
     * 玩家最大血量
     */
    public hpMax: number;

    /**
     * 玩家能量
     */
    public mp: number;

    /**
     * 玩家最大能量
     */
    public mpMax: number;

    /**
     * 玩家能量回复值
     */
    public mpValue: number;

    /**
     * 玩家x向量
     */
    public vectorX: number;

    /**
     * 玩家x向量
     */
    public vectorY: number;

    /**
     * 玩家旋转x向量
     */
    public angleX: number;

    /**
     * 玩家旋转y向量
     */
    public angleY: number;

    /**
     * 玩家移动速度
     */
    public speed: number;

    /**
     * 玩家宽度
     */
    public width: number;

    /**
     * 玩家高度
     */
    public height: number;

    /**
     * 玩家技能列表
     */
    public skillList: lSkill[] = [];

    /**
     * 技能计数列表
     */
    public skillCountList: SkillCount[] = [];

    /**
     * 玩家回复能量当前冷却
     */
    public mpInterval: number;

    /**
     * 玩家回复能量冷却时间
     */
    public mpMaxInterval: number;

    /**
     * 复活时间计数
     */
    public reStartCount: number;

    /**
     * 聊天文本存在时间计数
     */
    public chatCount: number;

    /**
     * 聊天内容
     */
    public chatText: string;

    constructor(id: number, name: string, isRobot: boolean, userId: number, teamId: number) {
        this.id = id;
        this.name = name;
        this.isRobot = isRobot;
        this.userId = userId;
        this.teamId = teamId;

        this.attackInterval = 0;
        this.attackMaxInterval = 20;
        this.isAttack = false;

        this.vectorX = 0;
        this.vectorY = 0;
        this.angleX = 0;
        this.angleY = -1;
        this.speed = 4;
        this.width = 80;
        this.height = 80;

        let frameRate: number = Logic.instance.frameRate;

        this.reStartCount = 0;

        this.setSkillCount("能量护盾");
        this.setSkillCount("飞弹术");
        this.setSkillCount("魔飞弹术");
        this.setSkillCount("虚无术");
        this.setSkillCount("吸血术");
        this.setSkillCount("高速滑轮");
        this.setSkillCount("狂暴");
        this.setSkillCount("穿透弹");
        this.setSkillCount("持久弹");
        this.setSkillCount("巨型弹");
        this.setSkillCount("双向弹");

        this.rank = 1;
        this.rankMax = 15;

        this.experience = 0;

        this.mpValue = 50;

        this.mpInterval = 0;
        this.mpMaxInterval = frameRate * 3;

        this.getSkillCount("能量护盾").count = frameRate * 2;

        // this.chatText = "";
        // this.chatCount = 0;

        if (this.teamId == 1) {
            this.chatText = "大家加油! 红队必胜!";
        }
        if (this.teamId == 2) {
            this.chatText = "大家加油! 黄队必胜!";
        }
        if (this.teamId == 3) {
            this.chatText = "大家加油! 蓝队必胜!";
        }
        this.chatCount = frameRate * 6;
    }

    public getSkill(name: string): lSkill {
        let skill: lSkill = undefined;
        for (let i: number = 0; i < this.skillList.length; i++) {
            if (this.skillList[i].name == name) {
                skill = this.skillList[i];
                return skill;
            }
        }
        return skill;
    }

    public getISkill(index: number): lSkill {
        let skill: lSkill = this.skillList[index];
        return skill;
    }

    public setSkill(newSkill: lSkill): void {
        let skill: lSkill = new lSkill("", 0, 0, false, "");

        for (let s in newSkill) {
            skill[s] = newSkill[s];
        }

        this.skillList.push(skill);
    }

    public setSkillCount(name: string): void {
        let skillCount: SkillCount = {
            name: name,
            count: 0
        };

        this.skillCountList.push(skillCount);
    }

    public getSkillCount(name: string): SkillCount {
        let skillCount: SkillCount = undefined;
        for (let i: number = 0; i < this.skillCountList.length; i++) {
            if (this.skillCountList[i].name == name) {
                skillCount = this.skillCountList[i];
            }
        }
        return skillCount;
    }

    public getISkillCount(index: number): SkillCount {
        let skillCount: SkillCount = this.skillCountList[index];
        return skillCount;
    }

}
