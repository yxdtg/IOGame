
/**
 * 子弹类
 */
export class lBullet {

    /**
     * 子弹id
     */
    public id: number;

    /**
     * 子弹类型
     */
    public type: string;

    /**
     * 玩家id
     */
    public parentId: number;

    /**
     * 角色id
     */
    public userId: number;

    /**
     * 队伍id
     */
    public teamId: number;

    /**
     * 子弹x坐标
     */
    public x: number;

    /**
     * 子弹y坐标
     */
    public y: number;

    /**
     * 子弹宽度
     */
    public width: number;

    /**
     * 子弹高度
     */
    public height: number;

    /**
     * 攻击计数
     */
    public count: number;

    /**
     * 攻击值
     */
    public attack: number;

    /**
     * 向量x
     */
    public vectorX: number;

    /**
     * 向量y
     */
    public vectorY: number;

    /**
     * 被攻击玩家id列表
     */
    public playerIds: number[];

    constructor(id: number, parentId: number, userId: number, teamId: number, type: string, x: number, y: number, width: number, height: number, vectorX: number, vectorY: number, count: number) {
        this.id = id;
        this.parentId = parentId;
        this.userId = userId;
        this.teamId = teamId;

        this.type = type;

        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.vectorX = vectorX;
        this.vectorY = vectorY;

        this.playerIds = [];

        this.count = count;
    }

}