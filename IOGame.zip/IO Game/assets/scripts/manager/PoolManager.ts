
import { _decorator, Component, Node, instantiate, Sprite, Color } from 'cc';
import { Game } from '../scene/Game';
import { ResourceManager } from './ResourceManager';
const { ccclass, property } = _decorator;

/**
 * 对象池管理类
 */
@ccclass('PoolManager')
export class PoolManager extends Component {

    /**
     * 对象池管理器
     */
    public static instance: PoolManager;

    private colorList: Color[] = [new Color(255, 255, 255, 0), new Color(255, 255, 255, 255)];

    // 子弹运行池
    private bulletList: Node[] = [];
    // 子弹存储池
    private _bulletList: Node[] = [];

    // 果实运行池
    private fruitList: Node[] = [];
    // 果实存储池
    private _fruitList: Node[] = [];

    onLoad() {
        PoolManager.instance = this;
    }

    public init(): void {

    }

    public clearBullet(): void {
        this.bulletList = [];
        this._bulletList = [];
    }

    public clearFruit(): void {
        this.fruitList = [];
        this._fruitList = [];
    }

    public initBullet(): void {
        for (let i: number = 0; i < 120; i++) {
            this.setActive(this.createBullet().getComponent(Sprite), false);
        }
    }

    public initFruit(): void {
        for (let i: number = 0; i < 120; i++) {
            this.setActive(this.createFruit().getComponent(Sprite), false);
        }
    }

    public createBullet(): Node {
        if (this._bulletList.length > 0) {
            let node: Node = this._bulletList.pop();
            this.setActive(node.getComponent(Sprite), true);
            this.bulletList.push(node);
            return node;
        } else {
            let node: Node = instantiate(ResourceManager.instance.getObject("Bullet"));
            node.parent = Game.instance.LayerBullet;
            this.bulletList.push(node);
            return node;
        }
    }

    public removeBullet(node: Node): void {
        let index: number = this.bulletList.indexOf(node);
        if (index != -1) {
            this.bulletList.splice(index, 1);
            this._bulletList.push(node);
            this.setActive(node.getComponent(Sprite), false);
        }
    }

    public createFruit(): Node {
        if (this._fruitList.length > 0) {
            let node: Node = this._fruitList.pop();
            this.setActive(node.getComponent(Sprite), true);
            this.fruitList.push(node);
            return node;
        } else {
            let node: Node = instantiate(ResourceManager.instance.getObject("Fruit"));
            node.parent = Game.instance.LayerFruit;
            this.fruitList.push(node);
            return node;
        }
    }

    public removeFruit(node: Node): void {
        let index: number = this.fruitList.indexOf(node);
        if (index != -1) {
            this.fruitList.splice(index, 1);
            this._fruitList.push(node);
            this.setActive(node.getComponent(Sprite), false);
        }
    }

    private setActive(sprite: Sprite, active: boolean): void {
        if (active) {
            sprite.color = this.colorList[1];
        } else {
            sprite.color = this.colorList[0];
        }
    }

}
