
import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

/**
 * UI管理类
 */
@ccclass('UIManager')
export class UIManager extends Component {

    /**
     * UI管理器
     */
    public static instance: UIManager;

    public uiList: { [name: string]: Node } = {}; // ui节点集合
    private persistenceList: { [name: string]: Node } = {}; // 持久性节点集合

    onLoad() {
        UIManager.instance = this;
    }

    /**
     * 加入ui节点集合
     * @param name 名称
     * @param node 节点
     */
    public setUI(name: string, node: Node): void {
        this.uiList[name] = node;
    }

    /**
     * 获取指定ui节点
     * @param name 名称
     * @returns 节点
     */
    public getUI(name: string): Node {
        return this.uiList[name];
    }

    /**
     * 移除指定ui节点
     * @param name 名称
     */
    public removeUI(name: string): void {
        delete this.uiList[name];
    }

    /**
     * 移除所有ui节点
     */
    public clearUI(): void {
        this.uiList = {};
    }

    /**
     * 加入持久性节点集合
     * @param name 名称
     * @param node 节点
     */
    public setPersistence(name: string, node: Node): void {
        this.persistenceList[name] = node;
    }

    /**
     * 获取指定持久性节点
     * @param name 名称
     * @returns 节点
     */
    public getPersistence(name: string): Node {
        return this.persistenceList[name];
    }

    /**
     * 移除指定持久性节点
     * @param name 名称
     */
    public removePersistence(name: string): void {
        delete this.persistenceList[name];
    }

    /**
     * 移除所有持久性节点
     */
    public clearPersistence(): void {
        this.persistenceList = {};
    }

}
