
import { _decorator, Component, Node, Label, EditBox, Color, Sprite, sys } from 'cc';
import { Logic } from '../scene/Logic';
import { Login } from '../scene/Login';
import { Main } from '../scene/Main';
import { cmd } from '../tool/cmdClient';
import { network } from '../tool/network';
import { GameManager } from './GameManager';
import { MessageManager } from './MessageManager';
import { ResourceManager } from './ResourceManager';
import { SceneManager } from './SceneManager';
import { UIManager } from './UIManager';
const { ccclass, property } = _decorator;

/**
 * 帧数据
 */
type Frame = {
    cmd: string,
    data: any[]
};

/**
 * 错误码
 */
let ErrorList: { [type: number]: string } = {
    0: "小队不存在",
    1: "匹配中无法执行该操作",
    2: "只有队长才可以执行该操作",
}

/**
 * 用户数据
 */
type userData = {
    /**
     * 账号
     */
    account: number,
    /**
     * 密码
     */
    password: string,
    /**
     * 等级
     */
    rank: number,
    /**
     * 经验
     */
    experience: number,
    /**
     * 金币
     */
    coin: number,
    /**
     * 宝石
     */
    gemstone: number,
    /**
     * 礼物次数
     */
    gift: number,
    /**
     * 上次登录时间
     */
    day: number,
    /**
     * 角色列表
     */
    roles: any[],
    /**
     * 道具列表
     */
    items: any[],
};

/**
 * 网络管理类
 */
@ccclass('NetManager')
export class NetManager extends Component {

    /**
     * 网络管理器
     */
    public static instance: NetManager;

    /**
     * 游戏版本
     */
    public gameVersion: number = 17;

    /**
     * 用户uid
     */
    public uid_: number = -1;
    /**
     * 用户昵称
     */
    public name_: string = "";
    /**
     * 用户头像id
     */
    public userId_: number = 0;
    /**
     * 用户队组id
     */
    public groupId_: number = -1;
    /**
     * 用户匹配id
     */
    public matchId_: number = -1;
    /**
     * 用户房间id
     */
    public roomId_: number = -1;
    /**
     * 用户队伍id
     */
    public teamId_: number = -1;

    /**
     * 用户等级
     */
    public rank_: number = -1;
    /**
     * 用户经验值
     */
    public experience_: number = -1;
    /**
     * 用户金币数量
     */
    public coin_: number = -1;
    /**
     * 用户宝石数量
     */
    public gemstone_: number = -1;
    /**
     * 用户礼物数量
     */
    public gift_: number = 0;
    /**
     * 用户登录日期
     */
    public day_: number = 0;
    /**
     * 用户角色列表
     */
    public roles_: any[] = [];
    /**
     * 用户道具列表
     */
    public items_: any[] = [];

    /**
     * 帧索引
     */
    public frame_: number = 0;

    /**
     * 用户技能列表
     */
    public skill_: string[] = [];

    public joystickType: number = 1;

    // private host: string = "192.168.0.100"; //
    private host: string = "47.111.75.169"; // 
    private port: number = 2001;

    private logic_: Logic = undefined;

    /**
     * 用户连接状态
     */
    public connectState: boolean = false;

    /**
     * 重连计数
     */
    private reconnectCount: number = 0;

    onLoad() {
        NetManager.instance = this;
    }

    start() {
        this.scheduleOnce(() => {
            this.sendHeartbeat();
        }, 3)
        this.scheduleOnce(() => {
            this.reconnect();
        }, 2)
    }

    /**
     * 初始化数据
     */
    private initData(): void {
        delete this.logic_;
        this.uid_ = -1;
        this.name_ = "";
        this.groupId_ = -1;
        this.matchId_ = -1;
        this.roomId_ = -1;
        this.teamId_ = -1;
        this.frame_ = 0;
    }

    /**
     * 游戏结束
     */
    public gameOver(): void {
        let uid: number = this.uid_;
        let name: string = this.name_;
        this.initData();
        this.uid_ = uid;
        this.name_ = name;

        SceneManager.instance.loadScene("Main");

        this.ping(1);
    }

    /**
     * 继续重连
     */
    public reconnectCountClear(): void {
        this.reconnectCount = 0;
        UIManager.instance.getUI("PageReconnect").active = false;
    }

    // 重新连接
    public reconnect(): void {
        this.scheduleOnce(() => {
            this.reconnect();
        }, 2)

        if (this.uid_ != -1 && !this.connectState) {
            if (this.reconnectCount < 10) {
                MessageManager.instance.createMessage("尝试连接服务器", 0, 1);
                this.connectServer(this.host, this.port);
                this.reconnectCount++;
                if (this.reconnectCount == 10) {
                    if (this.roomId_ == -1) {
                        MessageManager.instance.createMessage("服务器或网络错误", 0, 1);
                        SceneManager.instance.loadScene("Login");
                    } else {
                        // 房间内
                        UIManager.instance.getUI("PageReconnect").active = true;
                    }
                }
            }
        }
    }

    // 发送心跳包
    public sendHeartbeat(): void {
        this.scheduleOnce(() => {
            this.sendHeartbeat();
        }, 3)

        if (this.uid_ != -1) {
            if (this.connectState) {
                this.ping(0);
            }
        }
    }

    /**
     * 初始化
     */
    public init(): void {
        network.onOpen(this.onOpen, this);
        network.onClose(this.onClose, this);

        this.connectServer(this.host, this.port);
    }

    /**
     * 连接服务器
     * @param host 地址
     * @param port 端口
     */
    private connectServer(host: string, port: number): void {
        network.connect(host, port);
    }

    /**
     * 注册消息监听
     */
    private addHandler(): void {
        network.onOpen(this.onOpen, this);
        network.onClose(this.onClose, this);

        network.addHandler(cmd.connector_main_ping, this.onPing, this);
        network.addHandler(cmd.connector_main_login, this.onLogin, this);
        network.addHandler(cmd.connector_main_group, this.onGroup, this);
        network.addHandler(cmd.connector_main_match, this.onMatch, this);
        network.addHandler(cmd.connector_main_frame, this.onFrame, this);
        network.addHandler(cmd.connector_main_room, this.onRoom, this);
        network.addHandler(cmd.connector_main_error, this.onError, this);
    }

    /**
     * 移除消息监听
     */
    private removeHandler(): void {
        network.offOpen();
        network.offClose();

        network.removeThisHandlers(this);
    }

    // 连接服务器成功
    private onOpen(): void {
        console.log("连接服务器成功");
        MessageManager.instance.createMessage("连接服务器成功", 0, 1);
        this.connectState = true;

        this.removeHandler();
        this.addHandler();

        if (this.uid_ != -1) {
            this.room(0);
        } else {
            this.ping(1);
        }
    }

    // 与服务器断开连接
    private onClose(): void {
        MessageManager.instance.createMessage("与服务器断开连接", 0, 1);
        // this.connectState = false;
        console.log("与服务器断开连接");

    }

    // Ping消息监听
    private onPing(msg: { type: number, data: any[] }): void {
        // console.log(msg);
        let type: number = msg.type;
        let data: any = msg.data;

        if (type == 0) {
            // console.log(type);
            // console.log(data);
            let userData: userData = data;
            this.updateUserData(userData);
            // this.updateUserShow();
        }

        // console.log(msg);
        if (type == 1) {
            // 检测游戏版本
            let is: number = data[0];
            this.scheduleOnce(() => {
                if (is == 0) {
                    if (!UIManager.instance.getPersistence("PageGameVersion").active) {
                        UIManager.instance.getPersistence("PageGameVersion").active = true;
                    }
                    UIManager.instance.getPersistence("PageGameVersion").getChildByName("Label").getComponent(Label).string = "游戏不是最新版本，请到下载商店更新，或点击下方按钮下载最新版本";
                    UIManager.instance.getPersistence("ButtonUpdateGame").active = true;
                } else {
                    UIManager.instance.getPersistence("PageGameVersion").getChildByName("Label").getComponent(Label).string = "正在检测游戏版本...";
                    UIManager.instance.getPersistence("ButtonUpdateGame").active = false;
                    UIManager.instance.getPersistence("PageGameVersion").active = false;
                }
            }, 1)
        }

        if (type == 2) {
            // console.log(type);
            // console.log(data);
            let giftId: number = data[0];
            Main.instance.updateGift(giftId);
        }

        if (type == 3) {
        }
    }

    // 登录消息监听
    private onLogin(msg: { type: number, data: any[], roomId: number }): void {

        console.log(msg);
        let type: number = msg.type;

        // 注册失败
        if (type == 0) {
            console.log("注册失败");
            let value: string = "";
            let data: any = msg.data;
            if (data == 0) {
                value = "服务器错误";
            }
            if (data == 1) {
                value = "账号已存在";
            }
            MessageManager.instance.createMessage(value, 0, 1);
        }

        // 注册成功
        if (type == 1) {
            console.log("注册成功");
            MessageManager.instance.createMessage("注册成功", 0, 1);
        }

        // 登录失败
        if (type == 2) {
            console.log("登录失败");
            let value: string = "";
            let data: any = msg.data;
            if (data == 0) {
                value = "账号不存在";
            }
            if (data == 1) {
                value = "密码错误";
            }
            MessageManager.instance.createMessage(value, 0, 1);
        }

        // 登录成功
        if (type == 3) {
            console.log("登录成功");
            let userData: userData = msg.data[1];
            let uid: number = msg.data[0];
            let name: string = msg.data[2];
            let userId: number = msg.data[3];

            this.updateUserData(userData);

            let data: { uid: number, name: string, userId: number } = { uid: uid, name: name, userId: userId };
            this.uid_ = data.uid;
            this.name_ = data.name;
            this.userId_ = data.userId;

            MessageManager.instance.createMessage("登录成功, 欢迎, " + this.name_, 0, 1);

            let roomId: number = msg.roomId;
            if (roomId != undefined) {
                this.roomId_ = roomId;
                MessageManager.instance.createMessage("重连房间，数据恢复中...");
                this.createLogic();
                SceneManager.instance.loadScene("Game");
            } else {
                SceneManager.instance.loadScene("Main");
            }
        }

        // 账号在别处登录
        if (type == 4) {
            this.initData();
            console.log("账号在别处登录");
            MessageManager.instance.createMessage("账号在别处登录", 0, 1);
        }

    }

    // 队组消息监听
    public onGroup(msg: { type: number, data: any }): void {
        let type: number = msg.type;
        let data: any = msg.data;
        let groupId: number = data[0];
        let groupList: any[] = data[1];

        // 创建队组
        if (type == 0) {
            console.log("创建队组");
            MessageManager.instance.createMessage("创建小队成功", 0, 1);
            UIManager.instance.getUI("LayerGroup").active = true;
        }
        // 加入队组
        if (type == 1) {
            console.log("加入队组");
            MessageManager.instance.createMessage("加入小队成功", 0, 1);
            UIManager.instance.getUI("LayerGroup").active = true;
        }
        // 离开队组
        if (type == 2) {
            console.log("离开队组");
            MessageManager.instance.createMessage("退出小队成功", 0, 1);
            UIManager.instance.getUI("LayerGroup").active = false;
        }
        // 离开队组(被踢)
        if (type == 3) {
            console.log("离开队组(被踢)");
            MessageManager.instance.createMessage("您被踢出了小队", 0, 1);
            UIManager.instance.getUI("LayerGroup").active = false;
        }
        // 更新队组
        if (type == 4) {
            console.log("更新队组", groupList);
            this.groupId_ = groupId;
            UIManager.instance.getUI("LabelGroupId").getComponent(Label).string = "小队号: " + this.groupId_;
            let groupPlayerList: Node[] = UIManager.instance.getUI("LayoutGroup").children;
            for (let i: number = 0; i < groupPlayerList.length; i++) {
                let groupPlayer: Node = groupPlayerList[i];
                groupPlayer.getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("GroupPlayer");
                groupPlayer.getChildByName("Label").getComponent(Label).string = "";
                groupPlayer.getChildByName("Label").getComponent(Label).color = new Color(0, 0, 0, 255);
                groupPlayer.getChildByName("Button").active = false;
            }
            for (let i: number = 0; i < groupPlayerList.length; i++) {
                let groupPlayer: Node = groupPlayerList[i];
                if (i < groupList.length) {
                    groupPlayer.getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("Player" + groupList[i].userId);
                    groupPlayer.getChildByName("Label").getComponent(Label).string = groupList[i].name;
                    if (groupList[i].name == this.name_) {
                        groupPlayer.getChildByName("Label").getComponent(Label).color = new Color(255, 0, 0, 255);
                    }
                    if (i != 0) {
                        groupPlayer.getChildByName("Button").active = true;
                    }
                }
            }
        }
    }

    // 匹配消息监听
    public onMatch(msg: { type: number, data: any }) {
        // console.log(msg);
        let type: number = msg.type;
        let data: any = msg.data;

        // 匹配中
        if (type == 0) {
            console.log("匹配中");
            MessageManager.instance.createMessage("匹配中", 0, 1);
            UIManager.instance.getUI("ViewMatch").active = true;
        }
        // 匹配取消
        if (type == 1) {
            console.log("匹配取消");
            MessageManager.instance.createMessage("匹配取消", 0, 1);
            UIManager.instance.getUI("ViewMatch").active = false;
        }
        // 匹配成功
        if (type == 2) {
            console.log("匹配成功");
            MessageManager.instance.createMessage("匹配成功", 0, 1);
            this.roomId_ = data.roomId;
            this.createLogic();
            console.log("房间id: " + this.roomId_);
            // console.log(Logic.instance);
            SceneManager.instance.loadScene("Game");
        }
    }

    // 创建逻辑层
    public createLogic(): void {
        this.logic_ = new Logic(GameManager.instance.getSkillList(), GameManager.instance.getPlayerValueList());
    }

    // 帧数据
    public onFrame(msg: { type: number, data: any[] }): void {
        // console.log(msg);
        if (this.roomId_ == -1) {
            return;
        }
        let type: number = msg.type;
        let data: Frame[] = msg.data;

        // 收到数据帧
        if (type == 0) {
            this.addFrame(data);
        }
    }

    // 房间
    public onRoom(msg: { type: number, data: any }): void {
        let type: number = msg.type;
        let data: any = msg.data;

        console.log("重连"); // 2022年4月2日22:36:46 未完善 明天继续 拜拜cocos vscode 晚安
        // 完成 2022年4月3日11:36:07
        // 重连大厅
        if (type == 0) {
            console.log("重连大厅");
            console.log(msg);
            this.initData();
            this.uid_ = data.id;
            this.name_ = data.name;
            this.userId_ = data.userId;
            SceneManager.instance.loadScene("Main");
        }

        // 重连房间
        if (type == 1) {
            console.log("重连房间");
            console.log("Frame Count: " + data.length);
            for (let i: number = 0; i < data.length; i++) {
                this.addFrame(data[i]);
            }
        }

        // 房间不存在
        if (type == 2) {
            console.log("房间不存在");
            MessageManager.instance.createMessage("游戏已结束", 0, 1);
            this.gameOver();
            this.uid_ = data.id;
            this.name_ = data.name;
            this.userId_ = data.userId;
        }

        // 账号在别处登录
        if (type == 3) {
            this.initData();
            console.log("账号在别处登录");
            MessageManager.instance.createMessage("账号在别处登录", 0, 1);
            SceneManager.instance.loadScene("Login");
        }

        // 非重连房间
        if (type != 1) {
            this.ping(1);
        }

    }

    // 错误码
    public onError(type: number): void {
        MessageManager.instance.createMessage(ErrorList[type], 0, 1);
    }

    /**
     * ping 0-发送心跳包 1-检测版本更新
     */
    public ping(type: number): void {
        // 发送心跳包
        if (type == 0) {
            this.sendMessage(cmd.connector_main_ping, { type: type, uid: this.uid_ });
        }

        // 检测版本更新
        if (type == 1) {
            this.sendMessage(cmd.connector_main_ping, { type: type, data: [this.gameVersion] });
        }

        // 每日好礼
        if (type == 2) {
            this.sendMessage(cmd.connector_main_ping, { type: type, uid: this.uid_ });
        }

        // 退出登录
        if (type == 3) {
            this.sendMessage(cmd.connector_main_ping, { type: type, uid: this.uid_ });
        }

        // 技能更新
        if (type == 4) {
            this.sendMessage(cmd.connector_main_ping, { type: type, uid: this.uid_, data: this.skill_ });
        }
    }

    /**
     * 登录
     * @param name 昵称
     */
    public login(type: number, data: any): void {
        this.sendMessage(cmd.connector_main_login, { type: type, data: data });
    }

    /**
     * 队组
     * @param type 类型 0-创建 1-加入 2-离开 3-踢出
     */
    public group(type: number, removeId?: number): void {
        // 创建队组
        if (type == 0) {
            if (this.skill_.length == 4) {
                this.sendMessage(cmd.connector_main_group, { type: type, uid: this.uid_ });
                this.ping(4);
                this.saveSkillData();
            } else {
                MessageManager.instance.createMessage("技能未选择完成", 0, 1);
            }
        }
        // 加入队组
        if (type == 1) {
            if (this.skill_.length == 4) {
                let str: string = UIManager.instance.getUI("EditBoxGroupId").getComponent(EditBox).string;
                if (str.length != 0) {
                    let groupId: number = Number(str);
                    this.sendMessage(cmd.connector_main_group, { type: type, uid: this.uid_, groupId: groupId });
                    this.ping(4);
                    this.saveSkillData();
                } else {
                    console.log("队组id不可为空");
                    MessageManager.instance.createMessage("小队码不可为空", 0, 1);
                }
            } else {
                MessageManager.instance.createMessage("技能未选择完成", 0, 1);
            }
        }
        // 离开队组
        if (type == 2) {
            this.sendMessage(cmd.connector_main_group, { type: type, uid: this.uid_, groupId: this.groupId_ });
        }
        // 队组中移除指定玩家
        if (type == 3) {
            this.sendMessage(cmd.connector_main_group, { type: type, uid: this.uid_, groupId: this.groupId_, removeId: removeId });
        }
    }

    public saveSkillData(): void {

        let skillData: any = {
            skills: this.skill_,
        }

        sys.localStorage.setItem("skillData", JSON.stringify(skillData));
    }

    /**
     * 匹配
     * @param type 类型 0-发起匹配 1-取消匹配
     */
    public match(type: number): void {
        // 发起匹配
        if (type == 0) {
            this.sendMessage(cmd.connector_main_match, { type: type, uid: this.uid_, groupId: this.groupId_ });
        }
        if (type == 1) {
            this.sendMessage(cmd.connector_main_match, { type: type, uid: this.uid_, groupId: this.groupId_ });
        }
    }

    /**
     * 帧数据
     * @param type 类型
     * @param data 数据
     */
    public frame(data: Frame[]): void {
        // 发送帧数据包
        this.sendMessage(cmd.connector_main_frame, { roomId: this.roomId_, data: data });
        // // 断线重连
        // if (type == 1) {
        //     this.sendMessage(cmd.connector_main_frame, { type: type, roomId: this.roomId_, data: [this.uid_, this.roomId_] });
        // }
    }

    /**
     * 房间
     * @param type 类型
     */
    public room(type: number): void {
        // 断线重连
        if (type == 0) {
            this.sendMessage(cmd.connector_main_room, { type: 0, uid: this.uid_, name: this.name_, userId: this.userId_, roomId: this.roomId_, frame: this.frame_ });
        }
    }

    /**
     * 收到帧数据
     * @param frame 
     */
    private addFrame(frame: Frame[]): void {
        this.frame_ += 1;
        Logic.instance.addFrame(frame);
        Logic.instance.addFrame([]);
        Logic.instance.addFrame([]);
        Logic.instance.addFrame([]);
        // console.log(frame);
    }

    /**
     * 向服务器发送消息
     * @param cmd_ 消息类型
     * @param data_ 消息数据
     */
    public sendMessage(cmd_: cmd, data_: any): void {
        network.sendMsg(cmd_, data_);
    }

    /**
     * 场景加载完成回调
     * @param name 场景名称
     */
    public loadSceneDone(name: string): void {

        if (name == "Login") {
            this.init();
        }

        if (name == "Main") {
            this.updateUserImage();
            UIManager.instance.getUI("LabelName").getComponent(Label).string = this.name_; // 昵称

            this.updateUserShow();

            let skillData: any = JSON.parse(sys.localStorage.getItem("skillData"));
            if (skillData != undefined) {
                this.skill_ = skillData.skills;
                Main.instance.updateSkillShow();
            }
        }

        this.scheduleOnce(() => {
            UIManager.instance.getPersistence("PageLoadScene").active = false;
        }, 0.5)
    }

    update() {
        network.readMsg();
    }

    /**
     * 选择用户头像
     * @param id 头像id
     */
    public ChooseUserImage(id: number): void {
        this.userId_ = id;

        this.updateUserImage();

        if (UIManager.instance.getUI("PageChooseUser").active) {
            UIManager.instance.getUI("PageChooseUser").active = false;
        }
    }

    /**
     * 更新用户头像
     */
    public updateUserImage(): void {
        UIManager.instance.getUI("ImageUser").getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("Player" + this.userId_);
    }

    /**
     * 更新用户数据
     */
    public updateUserData(userData: userData): void {
        this.rank_ = userData.rank;
        this.experience_ = userData.experience;
        this.coin_ = userData.coin;
        this.gemstone_ = userData.gemstone;
        this.gift_ = userData.gift;
        this.day_ = userData.day;
        this.roles_ = userData.roles;
        this.items_ = userData.items;
    }

    /**
     * 更新用户数据显示
     */
    public updateUserShow(): void {
        UIManager.instance.getUI("LabelRank").getComponent(Label).string = "等级:" + this.rank_; // 等级
        UIManager.instance.getUI("LabelExperience").getComponent(Label).string = "经验:" + this.experience_ + "/" + (this.rank_ * 1000); // 经验
        UIManager.instance.getUI("CoinBox").getChildByName("Label").getComponent(Label).string = "" + this.coin_; // 金币
        UIManager.instance.getUI("GemstoneBox").getChildByName("Label").getComponent(Label).string = "" + this.gemstone_; // 宝石
    }

    /**
     * 旋转-每日好礼
     */
    public startGift(): void {
        this.ping(2);
    }

    /**
     * 退出登录
     */
    public quitLogin(): void {
        this.ping(3);

        this.initData();
        SceneManager.instance.loadScene("Login");
    }
}
