
import { _decorator, Component, Node, game, view, instantiate, Vec2, sys, EditBox, Camera, find } from 'cc';
import { lSkill } from '../logic/lSkill';
import { DeviceModule } from '../tool/DeviceModule';
import { Sensitive } from '../tool/Sensitive';
import { AudioManager } from './AudioManager';
import { MessageManager } from './MessageManager';
import { NetManager } from './NetManager';
import { ResourceManager } from './ResourceManager';
import { SceneManager } from './SceneManager';
import { UIManager } from './UIManager';
const { ccclass, property } = _decorator;

/**
 * 技能类
 */
type Skill = {
    name: string,
    interval: number,
    intervalMax: number,
    mp: number,
    isOneOff: boolean,
};

type pValue = {
    hpMax: number,
    mpMax: number,
    experienceMax: number,
    attack: number,
};

/**
 * 游戏管理类
 */
@ccclass('GameManager')
export class GameManager extends Component {

    /**
     * 游戏管理器
     */
    public static instance: GameManager;

    public resNum: number = 0; // 资源进度加载值
    public resMaxNum: number = 4; // 资源进度总加载值

    public sensitive: Sensitive = undefined;

    onLoad() {
        GameManager.instance = this;
    }

    start() {
        this.scheduleOnce(() => {
            this.initRes();
        }, 0.5)
    }

    private getVector(x: number, y: number): { x: number, y: number } {
        // let vectorX: number = y / (Math.sqrt(x * x + y * y));
        // let vecotrY: number = -x / (Math.sqrt(x * x + y * y));
        let vector: Vec2 = new Vec2(x, y);
        vector.normalize();
        let vectorX: number = Math.floor(vector.x * 1000) / 1000;
        let vecotrY: number = Math.floor(vector.y * 1000) / 1000;
        return { x: vectorX, y: vecotrY };
    }

    /**
     * 初始化资源
     */
    private initRes(): void {
        SceneManager.instance.init();
        ResourceManager.instance.init();
        AudioManager.instance.init();

        // 加载 库
        this.sensitive = new Sensitive();

        this.initSkill();
    }

    /**
     * 初始化游戏
     */
    private initGame(): void {
        console.log("游戏资源加载完成");
        SceneManager.instance.loadScene("Login");

        this.setGameFps(61);
        console.log("游戏初始化");
        // let map: Node = instantiate(ResourceManager.instance.getObject("Map0"));
        // map.parent = this.node;
        // map.setPosition(0, 0);
        // this.scheduleOnce(()=>{
        //     SceneManager.instance.logMapData();
        // },2)
        // NetManager.instance.init();
        // this.openApp("tencent://message/?");
    }

    /**
     * 资源进度加载值+1
     */
    public addResNum(): void {
        this.resNum++;
        if (this.resNum == this.resMaxNum) {
            this.scheduleOnce(() => {
                this.initGame();
            }, 0.1)
        }
    }

    /**
     * 设置游戏帧率
     * @param value 帧率
     */
    public setGameFps(value: number): void {
        game.frameRate = value;
    }

    /**
     * 获取网络类型
     * @returns 无-0  wifi-1  移动数据-2
     */
    public getNetworkType(): number {
        return sys.getNetworkType();
    }

    /**
     * 获取手机电量
     * @returns 1~100
     */
    public getBatteryLevel(): number {
        return Math.floor(sys.getBatteryLevel() * 100);
    }

    /**
     * 复制内容到剪切板
     * @param text 
     */
    public copyToClipboard(text: string): void {
        DeviceModule.getInstance().copyToClipboard(text);
    }

    /**
     * 获取剪切版内容
     */
    public getCopyText(): void {
        DeviceModule.getInstance().getClipContent(GameManager.getCopyTextCallBack);
    }

    /**
     * 获取剪切版内容回调
     * @param text 
     */
    public static getCopyTextCallBack(text: string): void {
        console.log("获取剪切版内容回调", text);
        let groupId: number = Number(text);
        if (groupId != undefined) {
            UIManager.instance.getUI("EditBoxGroupId").getComponent(EditBox).string = "" + groupId;
        } else {
            MessageManager.instance.createMessage("小队码必须是数字组成", 0, 1);
        }
    }


    /**
     * 打开web页面/应用
     * @param url 地址
     */
    public openApp(url: string): void {
        sys.openURL(url);
    }


    private skillList: { [name: string]: lSkill } = {};

    private playerValueList: { [rank: number]: pValue } = {
        1: { hpMax: 800, mpMax: 800, experienceMax: 500, attack: 80 },
        2: { hpMax: 850, mpMax: 850, experienceMax: 600, attack: 90 },
        3: { hpMax: 900, mpMax: 900, experienceMax: 700, attack: 100 },
        4: { hpMax: 950, mpMax: 950, experienceMax: 800, attack: 110 },
        5: { hpMax: 1000, mpMax: 1000, experienceMax: 900, attack: 120 },
        6: { hpMax: 1100, mpMax: 1050, experienceMax: 1000, attack: 130 },
        7: { hpMax: 1200, mpMax: 1100, experienceMax: 1000, attack: 140 },
        8: { hpMax: 1300, mpMax: 1200, experienceMax: 1000, attack: 150 },
        9: { hpMax: 1400, mpMax: 1300, experienceMax: 1000, attack: 165 },
        10: { hpMax: 1550, mpMax: 1400, experienceMax: 1000, attack: 180 },
        11: { hpMax: 1700, mpMax: 1500, experienceMax: 1100, attack: 195 },
        12: { hpMax: 1850, mpMax: 1600, experienceMax: 1100, attack: 215 },
        13: { hpMax: 2000, mpMax: 1700, experienceMax: 1200, attack: 235 },
        14: { hpMax: 2200, mpMax: 1800, experienceMax: 1200, attack: 255 },
        15: { hpMax: 2400, mpMax: 1900, experienceMax: 0, attack: 280 },
    };

    private initSkill(): void {
        this.addSkill("闪烁", 20, 100, true, "向指定方向位移一段距离，若在移动中，则向移动方向闪烁，若不在移动，则向攻击方向闪烁");
        this.addSkill("治疗术", 30, 0, true, "恢复自身25%最大生命值与魔法值");
        this.addSkill("飞弹术", 30, 100, true, "发动攻击时向随机方向发射2枚飞弹，飞弹攻击力为攻击力的50%，体积为50%，持续5秒");
        this.addSkill("魔飞弹术", 45, 100, true, "发动攻击时向随机方向发射5枚飞弹，飞弹攻击力为攻击力的30%，体积为40%，持续5秒");
        this.addSkill("空间穿梭", 60, 100, true, "立刻穿梭至地图随机一个位置，并获取护盾，护盾持续1秒");
        this.addSkill("能量护盾", 30, 100, true, "获取一个护盾，抵御其他玩家的攻击，持续2秒");
        this.addSkill("虚无术", 25, 100, true, "进入虚无状态，期间无视墙体，持续4秒");
        this.addSkill("魔法飞弹", 12, 100, true, "发射一枚大型飞弹，攻击力为释放者200%加成的攻击力");
        this.addSkill("吸血术", 25, 100, true, "进入吸血状态，期间攻击命中敌人回复造成伤害值的25%，持续5秒");
        this.addSkill("高速滑轮", 25, 100, true, "提升50%的移动速度，持续4秒");
        this.addSkill("狂暴", 25, 100, true, "提升50%的攻击速度，持续5秒");
        this.addSkill("穿透弹", 25, 100, true, "子弹将无视墙并且可以穿透敌人，持续5秒");
        this.addSkill("持久弹", 20, 100, true, "子弹飞行时间将延长50%，持续5秒");
        this.addSkill("巨型弹", 25, 100, true, "子弹体积增加50%，子弹攻击力提升20%，持续5秒");
        this.addSkill("双向弹", 25, 100, true, "发动攻击时向相反方向额外发射一颗子弹，该子弹攻击力为攻击力的50%，体积为80%，持续5秒");

        this.addSkill("不死血统", 0, 0, false, "自身所有血量回复效果提升25%");
        this.addSkill("魔泉", 0, 0, false, "自身所有魔法消耗减少15%");
        this.addSkill("护身石", 90, 0, false, "受到致命伤害时，将血量拉回至100点，并获得1秒护盾");
        this.addSkill("鹰眼", 0, 0, false, "额外获得15%的视野");
        this.addSkill("斗争心", 0, 0, false, "被击败后不会降级");
        this.addSkill("血液循环", 12, 0, false, "恢复自身6%的最大生命值");
        this.addSkill("近身战", 0, 0, false, "所有子弹飞行时间减少75%，子弹体积增加90%，子弹攻击力提升10%");
        this.addSkill("狙击手", 0, 0, false, "所有子弹飞行时间增加50%，子弹体积减少20%，子弹攻击力降低30%，站立不动时额外获得40%的视野");

        // console.log(this.skillList);
    }

    private addSkill(name: string, time: number, mp: number, isInput: boolean, text: string): void {
        let skill: lSkill = new lSkill(name, time * 60, mp, isInput, text);
        this.skillList[skill.name] = skill;
    }

    public getSkillList(): { [name: string]: lSkill } {
        return this.skillList;
    }

    public getPlayerValueList(): { [rank: number]: pValue } {
        return this.playerValueList;
    }
}
