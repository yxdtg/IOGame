
import { _decorator, Component, Node, instantiate, tween, Vec3, Label } from 'cc';
import { ResourceManager } from './ResourceManager';
import { SceneManager } from './SceneManager';
const { ccclass, property } = _decorator;

/**
 * 消息管理类
 */
@ccclass('MessageManager')
export class MessageManager extends Component {

    /**
     * 消息管理器
     */
    public static instance: MessageManager;

    onLoad() {
        MessageManager.instance = this;
    }

    start() {

    }

    /**
     * 创建消息
     * @param data 消息内容
     * @param type 消息类型 默认0
     * @param time 消息持续时间 默认1200ms
     */
    public createMessage(data: string, type?: number, time?: number): void {
        if (type == undefined) {
            type = 0;
        }
        if (time == undefined) {
            time = 1.2;
        }

        let message: Node = instantiate(ResourceManager.instance.getObject("Message" + type));
        message.parent = SceneManager.instance.node;
        message.setPosition(0, 290);
        message.getChildByName("Label").getComponent(Label).string = data;

        this.scheduleOnce(() => {
            tween(message)
                .to(time, { position: new Vec3(0, 480) })
                .call(() => {
                    message.destroy();
                })
                .start()
        }, time)
    }

}
