
import { _decorator, Component, Node, resources, Prefab, SpriteFrame } from 'cc';
import { GameManager } from './GameManager';
const { ccclass, property } = _decorator;

/**
 * 资源管理类
 */
@ccclass('ResourceManager')
export class ResourceManager extends Component {

    /**
     * 资源管理器
     */
    public static instance: ResourceManager;

    private objectList: { [name: string]: Prefab } = {}; // 对象集合
    private imageList: { [name: string]: SpriteFrame } = {}; // 图片集合

    public playerOffset: { [name: string]: number[] } = {};

    onLoad() {
        ResourceManager.instance = this;
    }

    /**
     * 初始化
     */
    public init(): void {
        resources.loadDir("prefab/object", Prefab, (err: Error, data: Prefab[]) => {
            if (err) {
                console.log("对象资源加载错误", err);
                return;
            }
            for (let object of data) {
                this.objectList[object.data.name] = object;
            }
            GameManager.instance.addResNum();
            console.log("对象资源加载完成");
            // console.log(this.objectList);

            let player: Node = this.getObject("Player").data;
            // console.log(player);

            for (let node of player.children) {
                this.playerOffset[node.name] = [node.position.x, node.position.y];
            }
            // console.log(this.playerOffset);
        })
        resources.loadDir("image", SpriteFrame, (err: Error, data: SpriteFrame[]) => {
            if (err) {
                console.log("图片资源加载错误", err);
                return;
            }
            for (let image of data) {
                this.imageList[image.name] = image;
            }
            GameManager.instance.addResNum();
            console.log("图片资源加载完成");
            // console.log(this.imageList);
        })
    }

    /**
     * 获取指定对象
     * @param name 对象名称
     */
    public getObject(name: string): Prefab {
        return this.objectList[name];
    }

    /**
     * 获取指定图片
     * @param name 图片名称
     */
    public getImage(name: string): SpriteFrame {
        return this.imageList[name];
    }

}
