
import { _decorator, Component, Node, Prefab, resources, instantiate, find, sys, Camera } from 'cc';
import { Collide } from '../object/Collide';
import { GameManager } from './GameManager';
import { NetManager } from './NetManager';
import { UIManager } from './UIManager';

const { ccclass, property } = _decorator;

/**
 * 碰撞类
 */
type CollideData = {
    /**
     * x坐标
     */
    x: number,
    /**
     * y坐标
     */
    y: number,
    /**
     * 宽度
     */
    width: number,
    /**
     * 高度
     */
    height: number
}

/**
 * 场景管理类
 */
@ccclass('SceneManager')
export class SceneManager extends Component {

    @property(Node)
    LayerScene: Node = undefined;

    /**
     * 场景管理器
     */
    public static instance: SceneManager;

    private sceneList: { [name: string]: Prefab } = {}; // 场景集合
    private currentScene: Node = undefined; // 当前运行场景

    private camera: Node = undefined; // 游戏摄像机

    private mapList: CollideData[] = [];

    onLoad() {
        SceneManager.instance = this;
    }

    /**
     * 初始化
     */
    public init(): void {
        this.camera = find("SceneManager/CameraGame");
        // console.log(this.camera.getComponent(Camera).orthoHeight);
        resources.loadDir("prefab/scene", Prefab, (err: Error, data: Prefab[]) => {
            if (err) {
                console.log("场景资源加载错误", err);
                return;
            }
            for (let scene of data) {
                this.sceneList[scene.data.name] = scene;
            }
            GameManager.instance.addResNum();
            console.log("场景资源加载完成");
            // console.log(this.sceneList);
        })
    }

    /**
     * 加载指定场景
     * @param name 场景名称
     */
    public loadScene(name: string): void {
        UIManager.instance.getPersistence("PageLoadScene").active = true;

        this.scheduleOnce(() => {

            if (this.currentScene != undefined) {
                this.currentScene.destroy();
            }

            this.scheduleOnce(() => {

                // 初始化摄像机坐标
                this.camera.setPosition(0, 0);
                this.camera.getComponent(Camera).orthoHeight = 360;

                let scene: Node = instantiate(this.sceneList[name]);
                scene.parent = this.LayerScene;
                scene.setPosition(0, 0);

                this.currentScene = scene;

                this.scheduleOnce(() => {
                    NetManager.instance.loadSceneDone(name);
                }, 0)
            })
        }, 0)

    }

    public addMapData(data: CollideData): void {
        this.mapList.push(data);
    }

    public logMapData(): void {
        console.log(JSON.stringify(this.mapList) + ";");
    }

    // 更新游戏
    public updateGame(): void {
        sys.openURL("https://fnx4mo5802.feishu.cn/drive/folder/fldcnGtZdy1MN5dg4DQchWlOuDg");
    }

}
