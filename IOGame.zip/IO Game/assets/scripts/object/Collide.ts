
import { _decorator, Component, Node, UITransform } from 'cc';
import { SceneManager } from '../manager/SceneManager';
const { ccclass, property } = _decorator;

@ccclass('Collide')
export class Collide extends Component {

    start() {
        // SceneManager.instance.addMapData({ x: this.node.position.x, y: this.node.position.y, width: this.node.getComponent(UITransform).width, height: this.node.getComponent(UITransform).height });
    }

}
