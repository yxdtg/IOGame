
import { _decorator, Component, Node, EditBox, Label, sys, UITransform, Sprite, instantiate } from 'cc';
import { MessageManager } from '../manager/MessageManager';
import { NetManager } from '../manager/NetManager';
import { ResourceManager } from '../manager/ResourceManager';
import { UIManager } from '../manager/UIManager';
import { Sensitive } from '../tool/Sensitive';
import { UserPlayer } from '../ui/UserPlayer';
const { ccclass, property } = _decorator;

@ccclass('Login')
export class Login extends Component {

    private nameList: string[] = [
        "朝歌晚酒",
        "都怪时光太动听",
        "时光凉,春衫薄",
        "笑我孤陋",
        "水墨青花",
        "っAngel′幻雪づ",
        "梦中有梦",
        "- 失梦者",
        "江山如画怎及你",
        "浅梦墨汐°",
        "❀笑靥如花ヅ",
        "且听风吟",
        "挽梦忆笙歌",
        "沫笙ゅ",
        "清风墨竹",
        "樱の舞",
        "半夏倾城",
        "南栀倾寒°",
        "入画浅相思",
        "旧雪烹茶",
        "若人生〆只如初见",
        "forever 浅笑°",
        "柚子泡芙",
        "醋拌柠檬",
        "初恋栀子花",
        "南海凝心",
        "暖风吹怀",
        "青桔味的风",
        "北街落初雨",
        "倾听夏末",
        "嗷哩个嗷~",
        "雪蕊幽香",
        "下一次微笑",
        "孤者何惧",
        "我心永恒",
        "永恒之心",
        "一步两步散步",
        "以风予你",
        "念于红尘",
        "番茄炒蛋",
        "黄焖鸡米饭",
        "辣子鸡",
        "浅花芯",
        "兮里怡",
        "殷九歌",
        "挽木琴",
        "清风叹",
        "夏日薄雪",
        "江南春失忆梦",
        "晚风听街雨",
        "你的眼里是星辰",
        "伴生梦",
        "蛋炒饭",
        "青椒炒蛋",
        "不想则不念",
        "念念不忘",
        "像雾像雨又像风",
        "小新要、小心",
        "心点时间到了",
        "你回来了~",
        "我回来了~"
    ];

    /**
     * 登录类管理器
     */
    public static instance: Login;

    onLoad() {
        Login.instance = this;
    }

    start() {
        // sys.localStorage.clear();
        this.scheduleOnce(() => {
            let accountData: any = JSON.parse(sys.localStorage.getItem("accountData"));
            if (accountData != undefined) {
                let name: EditBox = UIManager.instance.getUI("EditBoxName").getComponent(EditBox);
                let account: EditBox = UIManager.instance.getUI("EditBoxAccount").getComponent(EditBox);
                let password: EditBox = UIManager.instance.getUI("EditBoxPassword").getComponent(EditBox);
                name.string = accountData.name;
                NetManager.instance.ChooseUserImage(accountData.userId);
                account.string = accountData.account;
                password.string = accountData.password;
            } else {
                NetManager.instance.ChooseUserImage(NetManager.instance.userId_);
            }
        }, 0)
    }

    // 登录
    public login(): void {
        let name: string = UIManager.instance.getUI("EditBoxName").getComponent(EditBox).string;
        let account: string = UIManager.instance.getUI("EditBoxAccount").getComponent(EditBox).string;
        let password: string = UIManager.instance.getUI("EditBoxPassword").getComponent(EditBox).string;

        // 过滤敏感词
        let filterName: string = Sensitive.instance.filterSensitive(name);
        name = filterName;
        UIManager.instance.getUI("EditBoxName").getComponent(EditBox).string = filterName;

        if (name.length == 0) {
            console.log("昵称不能为空");
            MessageManager.instance.createMessage("昵称不能为空", 0, 1);
            return;
        }
        if (account.length == 0 || account.length < 6) {
            console.log("账号长度不符合规则");
            MessageManager.instance.createMessage("账号长度不符合规则", 0, 1);
            return;
        }

        let isNum: boolean = true;
        let accounts: string[] = [];
        for (let i: number = 0; i < account.length; i++) {
            accounts[i] = account[i];
        }
        // console.log(accounts);
        let strs: string[] = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];
        for (let i: number = 0; i < accounts.length; i++) {
            if (strs.indexOf(accounts[i]) == -1) {
                isNum = false;
            }
        }
        if (!isNum) {
            console.log(accounts);
            console.log("账号只能是数字组成");
            MessageManager.instance.createMessage("账号只能是数字组成", 0, 1);
            return;
        }

        if (password.length == 0 || password.length < 6) {
            console.log("密码长度不符合规则");
            MessageManager.instance.createMessage("密码长度不符合规则", 0, 1);
            return;
        }

        let accountData: any = {
            name: name,
            userId: NetManager.instance.userId_,
            account: account,
            password: password,
        };

        sys.localStorage.setItem("accountData", JSON.stringify(accountData));

        NetManager.instance.login(1, [name, NetManager.instance.userId_, account, password]);
    }

    // 注册
    public registration(): void {

        let account: string = UIManager.instance.getUI("EditBoxAccountR").getComponent(EditBox).string;
        let password: string = UIManager.instance.getUI("EditBoxPasswordR").getComponent(EditBox).string;
        let passwordR: string = UIManager.instance.getUI("EditBoxPasswordRR").getComponent(EditBox).string;
        if (account.length == 0 || account.length < 6) {
            console.log("账号长度不符合规则");
            MessageManager.instance.createMessage("账号长度不符合规则", 0, 1);
            return;
        }

        let isNum: boolean = true;
        let accounts: string[] = [];
        for (let i: number = 0; i < account.length; i++) {
            accounts[i] = account[i];
        }
        let strs: string[] = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];
        for (let i: number = 0; i < accounts.length; i++) {
            if (strs.indexOf(accounts[i]) == -1) {
                isNum = false;
            }
        }
        if (!isNum) {
            console.log(accounts);
            console.log("账号只能是数字组成");
            MessageManager.instance.createMessage("账号只能是数字组成", 0, 1);
            return;
        }

        if (password.length == 0 || password.length < 6) {
            console.log("密码长度不符合规则");
            MessageManager.instance.createMessage("密码长度不符合规则", 0, 1);
            return;
        }
        if (password != passwordR) {
            console.log("两次密码不一致");
            MessageManager.instance.createMessage("两次密码不一致", 0, 1);
            return;
        }

        NetManager.instance.login(0, [account, password]);
    }

    // 打开/关闭 注册页面
    public setRegistrationPage(a: any, b: string): void {
        if (b == "0") {
            UIManager.instance.getUI("PageRegistration").active = false;
        }
        if (b == "1") {
            UIManager.instance.getUI("PageRegistration").active = true;
        }
    }

    // 设置密码框显示状态
    public setPasswordShow(): void {
        let password: EditBox = UIManager.instance.getUI("EditBoxPassword").getComponent(EditBox);
        if (password.inputFlag == EditBox.InputFlag.PASSWORD) {
            password.inputFlag = EditBox.InputFlag.DEFAULT;
            UIManager.instance.getUI("LabelShowPassword").getComponent(Label).string = "*";
        } else {
            password.inputFlag = EditBox.InputFlag.PASSWORD;
            UIManager.instance.getUI("LabelShowPassword").getComponent(Label).string = "👀";
        }
    }

    // 获取随机昵称
    public getRandomName(): void {
        let index: number = Math.round(Math.random() * (this.nameList.length - 1));
        let name: string = this.nameList[index];
        UIManager.instance.getUI("EditBoxName").getComponent(EditBox).string = name;
    }

    // 打开/关闭选择用户头像
    public setUserPage(a: any, b: string): void {
        if (b == "0") {
            UIManager.instance.getUI("PageChooseUser").active = false;
        }
        if (b == "1") {
            UIManager.instance.getUI("PageChooseUser").active = true;
            this.scheduleOnce(() => {
                if (UIManager.instance.getUI("LayoutChooseUser").children.length == 0) {
                    for (let i: number = 0; i < 3; i++) {
                        let name: string = "Player" + i;
                        let node: Node = instantiate(ResourceManager.instance.getObject("UserPlayer"));
                        node.parent = UIManager.instance.getUI("LayoutChooseUser");
                        node.getComponent(UITransform).width = 80;
                        node.getComponent(UITransform).height = 80;
                        node.getComponent(UserPlayer).id = i;
                        node.getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage(name);
                    }
                    UIManager.instance.getUI("ViewChooseUser").getComponent(UITransform).width = (UIManager.instance.getUI("LayoutChooseUser").children.length * 50) + 5;
                }
            }, 0)
        }
    }

}
