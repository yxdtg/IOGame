
import { _decorator, Component, Node, instantiate, lerp, Vec3, Label, Sprite, Camera, find, color, Color, UITransform, Vec2, view, EditBox, tween } from 'cc';
import { lBullet } from '../logic/lBullet';
import { lAudio } from '../logic/lAudio';
import { lFruit } from '../logic/lFruit';
import { lLabel } from '../logic/lLabel';
import { lMessage } from '../logic/lMessage';
import { lPlayer } from '../logic/lPlayer';
import { AudioManager } from '../manager/AudioManager';
import { NetManager } from '../manager/NetManager';
import { ResourceManager } from '../manager/ResourceManager';
import { SceneManager } from '../manager/SceneManager';
import { UIManager } from '../manager/UIManager';
import { Sensitive } from '../tool/Sensitive';
import { Joystick } from '../ui/Joystick';
import { Logic } from './Logic';
import { PoolManager } from '../manager/PoolManager';
import { lSkill } from '../logic/lSkill';
const { ccclass, property } = _decorator;

/**
 * 帧数据
 */
type Frame = {
    cmd: string,
    data: any[]
};

/**
 * 逻辑层数据
 */
type Data = {
    players: lPlayer[],
    bullets: lBullet[],
    fruits: lFruit[],
    teamValues: { [id: number]: number },
    labels: lLabel[],
    audios: lAudio[],
    messages: lMessage[],
    time: number,
};

/**
 * 技能计数类
 */
type SkillCount = {
    name: string,
    count: number,
};

/**
 * 表现层玩家
 */
type gPlayer = {
    player: lPlayer,
    node: Node,
    angleX: number,
    angleY: number,
    index: number,
};

/**
 * 表现层子弹
 */
type gBullet = {
    bullet: lBullet,
    node: Node,
};

/**
 * 表现层果实
 */
type gFruit = {
    fruit: lFruit,
    node: Node,
    label: Node,
};

/**
 * 表现层文本
 */
type gLabel = {
    label: lLabel,
    node: Node,
    scale: number,
};

/**
 * 表现层管理类
 */
@ccclass('Game')
export class Game extends Component {

    /**
     * 层/玩家
     */
    @property(Node)
    LayerPlayer: Node = undefined;

    /**
     * 层/子弹
     */
    @property(Node)
    LayerBullet: Node = undefined;

    /**
     * 层/果实
     */
    @property(Node)
    LayerFruit: Node = undefined;

    /**
     * 层/文本
     */
    @property(Node)
    LayerLabel: Node = undefined;

    /**
     * 层/点
     */
    @property(Node)
    LayerPoint: Node = undefined;

    /**
     * 层/地图
     */
    @property(Node)
    LayerMap: Node = undefined;

    /**
     * 表现层管理器
     */
    public static instance: Game;

    private camera: Node = undefined; // 游戏摄像机

    private frameData: Frame[] = []; // 帧数据列表

    private fpsNum: number = 1 / 64; // 上传数据帧率
    private dtNum: number = 0; // 计数

    private fpsCount: number = 0; // 帧率计数
    private fpsValue: number = 60; // fps

    private playerList: { [id: number]: gPlayer } = {}; // 玩家列表
    private bulletList: { [id: number]: gBullet } = {}; // 子弹列表
    private fruitList: { [id: number]: gFruit } = {}; // 果实列表
    private labelList: { [id: number]: gLabel } = {}; // 文本列表

    private pointList: { [id: number]: Node } = {}; // 点列表

    private viewSize: number[] = [];

    private colorMp: Color[] = [new Color(0, 105, 255, 0), new Color(0, 105, 255, 105)];

    private teamColor: { [id: number]: Color } = {
        [1]: new Color(255, 0, 0, 255),
        [2]: new Color(255, 255, 0, 255),
        [3]: new Color(0, 255, 255, 255)
    };

    private teamName: { [id: number]: string } = {
        [1]: "红队",
        [2]: "黄队",
        [3]: "蓝队",
    };

    onLoad() {
        Game.instance = this;
    }

    onDestroy() {
        PoolManager.instance.clearBullet();
        PoolManager.instance.clearFruit();
    }

    start() {
        this.camera = find("SceneManager/CameraGame");
        // console.log(view.getViewportRect());
        this.viewSize = [view.getVisibleSize().width, view.getVisibleSize().height];

        let map: Node = instantiate(ResourceManager.instance.getObject("Map0"));
        map.parent = this.LayerMap;
        map.setPosition(0, 0);
        map.getChildByName("LayerCollide").destroy();
        // console.log(this.viewSize);

        PoolManager.instance.initBullet();
        PoolManager.instance.initFruit();

        // this.scheduleOnce(() => {
        //     UIManager.instance.getUI("ButtonAttack").on(Node.EventType.TOUCH_START, this.playerAttack, this);
        //     UIManager.instance.getUI("ButtonAttack").on(Node.EventType.TOUCH_END, this.playerStopAttack, this);
        //     UIManager.instance.getUI("ButtonAttack").on(Node.EventType.TOUCH_CANCEL, this.playerStopAttack, this);
        // }, 0)
    }

    /**
     * 缓存帧数据
     */
    public addFrame(frame: Frame): void {
        this.frameData.push(frame);
    }

    // 上传帧数据
    private fixedUpdate(): void {
        // console.log("fixedUpdate");
        if (this.frameData.length == 0) {
            return;
        }
        NetManager.instance.frame(this.frameData);
        this.frameData = [];
    }

    /**
     * 更新表现层
     */
    public updateGame(data: Data): void {

        let gameTime: number = data.time;

        let f: any = Math.floor(gameTime / 60); // 获取分
        let s: any = gameTime % 60; // 获取秒
        f += "";
        s += "";
        f = (f.length == 1) ? "0" + f : f;
        s = (s.length == 1) ? "0" + s : s;
        // console.log(f + ":" + s);
        UIManager.instance.getUI("LabelTime").getComponent(Label).string = f + ":" + s;

        let teamValues: { [id: number]: number } = data.teamValues;

        let teamvalueList: number[][] = [];

        for (let teamId in teamValues) {
            teamvalueList.push([Number(teamId), teamValues[teamId]]);
        }

        teamvalueList.sort((a: number[], b: number[]) => {
            return b[1] - a[1];
        })

        // console.log(teamvalueList);

        let rankingBox: Node = UIManager.instance.getUI("RankingBox");
        for (let i: number = 0; i < teamvalueList.length; i++) {
            let rankLabel: Label = rankingBox.getChildByName("Label" + i).getComponent(Label);
            rankLabel.color = this.teamColor[teamvalueList[i][0]];
            rankLabel.string = (i + 1) + "." + this.teamName[teamvalueList[i][0]] + ":" + teamvalueList[i][1];
        }

        if (gameTime == 0) {
            console.log("游戏结束");
            UIManager.instance.getUI("PageGameOver").active = true;
            UIManager.instance.getUI("PageGameOver").getChildByName("LabelTeam").getComponent(Label).color = this.teamColor[teamvalueList[0][0]];
            UIManager.instance.getUI("PageGameOver").getChildByName("LabelTeam").getComponent(Label).string = this.teamName[teamvalueList[0][0]] + " 胜利";
            return;
        }

        let players: lPlayer[] = data.players;

        for (let i: number = 0; i < players.length; i++) {
            let player: lPlayer = players[i];
            if (this.playerList[player.id] == undefined) {
                let node: Node = instantiate(ResourceManager.instance.getObject("Player"));
                node.parent = this.LayerPlayer.getChildByName("Player");
                node.getChildByName("Image").getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("Player" + player.userId);
                node.setPosition(player.x, player.y);

                node.getChildByName("LabelName").getComponent(Label).string = player.name;

                node.getChildByName("LabelName").getComponent(Label).color = this.teamColor[player.teamId];

                // 玩家子节点合批
                let childrenCount: number = node.children.length;
                for (let j: number = 0; j < childrenCount; j++) {
                    let childrenNode: Node = node.children[0];
                    let childrenName: string = childrenNode.name;
                    childrenNode.parent = this.LayerPlayer.getChildByName(childrenName);
                }

                if (player.id == NetManager.instance.uid_) {
                    NetManager.instance.teamId_ = player.teamId;
                    this.camera.setPosition(player.x, player.y);
                    for (let j: number = 0; j < players.length; j++) {
                        let otherPlayer: lPlayer = players[j];
                        if (otherPlayer.teamId == player.teamId && otherPlayer.id != player.id) {
                            let point: Node = instantiate(ResourceManager.instance.getObject("PointPlayer"));
                            point.parent = this.LayerPoint;
                            point.getChildByName("Label").getComponent(Label).string = otherPlayer.name;
                            point.setPosition(0, 0);

                            this.pointList[otherPlayer.id] = point;
                        }
                    }
                    // console.log(this.pointList);
                }
                let gPlayer: gPlayer = {
                    player: player,
                    node: node,
                    angleX: 0,
                    angleY: -1,
                    index: i
                }
                this.playerList[player.id] = gPlayer;
            }
            // let node: Node = this.playerList[player.id].node;
            // node.getChildByName("Label").getComponent(Label).string = "x: " + player.x + ", " + "y: " + player.y;
        }

        let bullets: lBullet[] = data.bullets;

        let bulletIds: number[] = [];
        let bulletIds_: number[] = [];

        for (let i: number = 0; i < bullets.length; i++) {
            let bullet: lBullet = bullets[i];
            bulletIds.push(bullet.id);
            if (this.bulletList[bullet.id] == undefined) {
                let node: Node = PoolManager.instance.createBullet();
                // node.getComponent(Sprite).color = this.teamColor[bullet.teamId];
                node.getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("Bullet" + bullet.userId);
                if (NetManager.instance.teamId_ != bullet.teamId) {
                    node.getComponent(Sprite).color = new Color(255, 255, 255, 155);
                }
                node.getComponent(UITransform).width = bullet.width;
                node.getComponent(UITransform).height = bullet.height;
                node.setPosition(bullet.x, bullet.y);

                let gBullet: gBullet = {
                    bullet: bullet,
                    node: node
                }
                this.bulletList[bullet.id] = gBullet;
            }
        }

        for (let id in this.bulletList) {
            let bulletId: number = Number(id);
            if (bulletIds.indexOf(bulletId) == -1) {
                bulletIds_.push(bulletId);
            }
        }

        for (let i: number = 0; i < bulletIds_.length; i++) {
            PoolManager.instance.removeBullet(this.bulletList[bulletIds_[i]].node);
            delete this.bulletList[bulletIds_[i]];
        }

        let fruits: lFruit[] = data.fruits;

        let fruitIds: number[] = [];
        let fruitIds_: number[] = [];

        for (let i: number = 0; i < fruits.length; i++) {
            let fruit: lFruit = fruits[i];
            fruitIds.push(fruit.id);
            if (this.fruitList[fruit.id] == undefined) {
                let fType: number = fruit.type;
                let node: Node = undefined;
                if (fType == 3) {
                    node = instantiate(ResourceManager.instance.getObject("SkillFruit"));
                } else {
                    node = PoolManager.instance.createFruit();
                }
                node.setPosition(fruit.x, fruit.y);
                node.getComponent(UITransform).width = fruit.width;
                node.getComponent(UITransform).height = fruit.height;
                let name: string = "";
                let label: Node = undefined;
                if (fType == 0) {
                    name = "HpFruit";
                    node.parent = this.LayerFruit.getChildByName("A");
                }
                if (fType == 1) {
                    name = "MpFruit";
                    node.parent = this.LayerFruit.getChildByName("B");
                }
                if (fType == 2) {
                    name = "ExperienceFruit";
                    node.parent = this.LayerFruit.getChildByName("C");
                }
                if (fType == 3) {
                    name = "SkillFruit";
                    node.parent = this.LayerFruit.getChildByName("D");
                    label = node.getChildByName("Label");
                    label.getComponent(Label).string = fruit.name;
                    let offsetX: number = label.position.x;
                    let offsetY: number = label.position.y;
                    label.parent = this.LayerFruit.getChildByName("E");
                    label.setPosition(node.position.x + offsetX, node.position.y + offsetY);
                }
                node.getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage(name);

                let gFruit: gFruit = {
                    fruit: fruit,
                    node: node,
                    label: label,
                }
                this.fruitList[fruit.id] = gFruit;
            }
        }

        for (let id in this.fruitList) {
            let fruitId: number = Number(id);
            if (fruitIds.indexOf(fruitId) == -1) {
                fruitIds_.push(fruitId);
            }
        }

        for (let i: number = 0; i < fruitIds_.length; i++) {
            let gFruit: gFruit = this.fruitList[fruitIds_[i]];
            if (gFruit.fruit.type == 3) {
                gFruit.node.destroy();
                gFruit.label.destroy();
            } else {
                PoolManager.instance.removeFruit(gFruit.node);
            }
            delete this.fruitList[fruitIds_[i]];
        }

        let labels: lLabel[] = data.labels;

        let labelIds: number[] = [];
        let labelIds_: number[] = [];

        for (let i: number = 0; i < labels.length; i++) {
            let label: lLabel = labels[i];
            labelIds.push(label.id);
            if (this.labelList[label.id] == undefined) {
                let node: Node = instantiate(ResourceManager.instance.getObject("LabelShow"));
                node.parent = this.LayerLabel;
                node.setPosition(label.x, label.y);
                node.getComponent(Label).color = new Color(label.color[0], label.color[1], label.color[2], label.color[3]);
                node.getComponent(Label).string = label.value;

                let gLabel: gLabel = {
                    label: label,
                    node: node,
                    scale: node.scale.x
                };
                this.labelList[label.id] = gLabel;
            }
        }

        for (let id in this.labelList) {
            let labelId: number = Number(id);
            if (labelIds.indexOf(labelId) == -1) {
                labelIds_.push(labelId);
            }
        }

        for (let i: number = 0; i < labelIds_.length; i++) {
            this.labelList[labelIds_[i]].node.destroy();
            delete this.labelList[labelIds_[i]];
        }

        let audios: lAudio[] = data.audios;

        for (let i: number = 0; i < audios.length; i++) {
            let audio: lAudio = audios[i];

            let pos: Vec2 = new Vec2(this.playerList[NetManager.instance.uid_].player.x, this.playerList[NetManager.instance.uid_].player.y);
            let npos: Vec2 = new Vec2(audio.x, audio.y);
            let distance: number = Vec2.distance(pos, npos);

            if (distance < 480) {
                AudioManager.instance.playAudio(audio.name);
            }
        }

        let messages: lMessage[] = data.messages;

        if (messages.length == 0) {
            UIManager.instance.getUI("LabelMessage").getComponent(Label).string = "";
        } else {
            let message: lMessage = messages[messages.length - 1];
            UIManager.instance.getUI("LabelMessage").getComponent(Label).string = message.value;
        }

    }

    update(dt: number) {

        // 驱动逻辑层
        Logic.instance.update(dt);

        let playerRate: number = dt * 10;
        let attackRate: number = dt * 12;
        let labelRate: number = dt * 10;

        for (let id in this.playerList) {
            let gPlayer: gPlayer = this.playerList[id];
            let player: lPlayer = gPlayer.player;
            let node: Node = gPlayer.node;

            let index: number = gPlayer.index;

            this.lerpMove(player, node, playerRate);

            // updatePos..
            if (node.position.x < -10000 || node.position.y < -10000) {
                node.setPosition(player.x, player.y);
            }

            if (gPlayer.angleX != player.angleX || gPlayer.angleY != player.angleY) {

                // 计算偏移
                let offsetX: number = (player.angleX - gPlayer.angleX) * playerRate;
                let offsetY: number = (player.angleY - gPlayer.angleY) * playerRate;

                // 新坐标
                let posX: number = gPlayer.angleX + offsetX;
                let posY: number = gPlayer.angleY + offsetY;

                if ((offsetX > 0 && posX > player.angleX) || (offsetX < 0 && posX < player.angleX)) {
                    posX = player.angleX;
                }
                if ((offsetY > 0 && posY > player.angleY) || (offsetY < 0 && posY < player.angleY)) {
                    posY = player.angleY;
                }

                gPlayer.angleX = posX;
                gPlayer.angleY = posY;

                let r: number = Math.atan2(gPlayer.angleY, gPlayer.angleX);
                let angle: number = r * 180 / Math.PI;
                this.LayerPlayer.getChildByName("Direction").children[gPlayer.index].angle = angle;
            }

            let offset: { [name: string]: number[] } = ResourceManager.instance.playerOffset;

            // 更新玩家子节点坐标
            for (let name in offset) {
                let pos: number[] = offset[name];
                this.LayerPlayer.getChildByName(name).children[index].setPosition(node.position.x + pos[0], node.position.y + pos[1]);
            }

            // 更新玩家属性显示
            this.LayerPlayer.getChildByName("HpStrip").children[gPlayer.index].getComponent(Sprite).fillRange = (player.hp / player.hpMax);
            this.LayerPlayer.getChildByName("MpStrip").children[gPlayer.index].getComponent(Sprite).fillRange = (player.mp / player.mpMax);
            this.LayerPlayer.getChildByName("ExperienceStrip").children[gPlayer.index].getComponent(Sprite).fillRange = (player.experience / player.experienceMax);
            this.LayerPlayer.getChildByName("LabelRank").children[gPlayer.index].getComponent(Label).string = "" + player.rank;
            this.LayerPlayer.getChildByName("LabelHp").children[gPlayer.index].getComponent(Label).string = "" + player.hp;
            this.LayerPlayer.getChildByName("LabelMp").children[gPlayer.index].getComponent(Label).string = "" + player.mp;
            if (player.getSkillCount("能量护盾").count > 0) {
                if (this.LayerPlayer.getChildByName("Shield").children[gPlayer.index].getComponent(Sprite).color.a == 0) {
                    this.LayerPlayer.getChildByName("Shield").children[gPlayer.index].getComponent(Sprite).color = new Color(255, 255, 255, 105);
                }
            } else {
                if (this.LayerPlayer.getChildByName("Shield").children[gPlayer.index].getComponent(Sprite).color.a == 105) {
                    this.LayerPlayer.getChildByName("Shield").children[gPlayer.index].getComponent(Sprite).color = new Color(255, 255, 255, 0);
                }
            }
            if (player.chatCount > 0) {
                this.LayerPlayer.getChildByName("LabelChat").children[gPlayer.index].getComponent(Label).string = player.chatText;
                this.LayerPlayer.getChildByName("ChatBox").children[gPlayer.index].getComponent(Sprite).color = new Color(255, 255, 255, 205);
            } else {
                this.LayerPlayer.getChildByName("LabelChat").children[gPlayer.index].getComponent(Label).string = "";
                this.LayerPlayer.getChildByName("ChatBox").children[gPlayer.index].getComponent(Sprite).color = new Color(255, 255, 255, 0);
            }

            let skillCount0: SkillCount = player.getSkillCount("虚无术");
            if (skillCount0.count > 0) {
                let Image: Node = this.LayerPlayer.getChildByName("Image").children[gPlayer.index];
                if (Image.getComponent(Sprite).color.a == 255) {
                    Image.getComponent(Sprite).color = new Color(255, 255, 255, 155);
                }
            } else {
                let Image: Node = this.LayerPlayer.getChildByName("Image").children[gPlayer.index];
                if (Image.getComponent(Sprite).color.a == 155) {
                    Image.getComponent(Sprite).color = new Color(255, 255, 255, 255);
                }
            }

            // 本地玩家
            if (player.id == NetManager.instance.uid_) {
                if (player.reStartCount > 0) {
                    // 复活页面show
                    if (!UIManager.instance.getUI("PageReStart").active) {
                        UIManager.instance.getUI("PageReStart").active = true;
                        this.scheduleOnce(() => {
                            UIManager.instance.getUI("Joystick").getComponent(Joystick).onRockerOver();
                        }, 0)
                    }
                    if (UIManager.instance.getUI("LabelReStart") != undefined) {
                        UIManager.instance.getUI("LabelReStart").getComponent(Label).string = "复活中." + Math.ceil(player.reStartCount / 60) + "s";
                    }
                }
                if (player.reStartCount == 0) {
                    // 复活页面!show
                    if (UIManager.instance.getUI("PageReStart").active) {
                        UIManager.instance.getUI("LabelReStart").getComponent(Label).string = "";
                        UIManager.instance.getUI("PageReStart").active = false;
                    }
                    this.camera.setPosition(node.position.x, node.position.y);
                }

                let cmaeraSize: number = 360;
                let rate: number = 0.2;

                if (player.getSkill("鹰眼") != undefined) {
                    cmaeraSize = cmaeraSize * 1.15;
                }

                if (player.getSkill("狙击手") != undefined) {
                    // 站立不动
                    if (player.vectorX == 0 && player.vectorY == 0) {
                        cmaeraSize = cmaeraSize * 1.4;
                    } else {
                        cmaeraSize = cmaeraSize;
                    }
                }

                this.camera.getComponent(Camera).orthoHeight = lerp(this.camera.getComponent(Camera).orthoHeight, cmaeraSize, rate);

                // UIManager.instance.getUI("AttackStrip").getComponent(Sprite).fillRange = attack.interval / attack.intervalMax;
                let skillCount: number = player.skillList.length - 2;

                for (let i: number = 0; i < 4; i++) {
                    if (skillCount >= 1 + i) {
                        let skill: lSkill = player.getISkill(2 + i);
                        if (UIManager.instance.getUI("ButtonSkill" + i).getChildByName("Label").getComponent(Label).string == "") {
                            let sName: string = "";
                            if (skill.isInput) {
                                sName = skill.name;
                            } else {
                                sName = "*" + skill.name;
                            }
                            UIManager.instance.getUI("ButtonSkill" + i).getChildByName("Label").getComponent(Label).string = sName;
                        }
                        if (skill.isInput || skill.intervalMax > 0) {
                            UIManager.instance.getUI("ButtonSkill" + i).getChildByName("Strip").getComponent(Sprite).fillRange = skill.interval / skill.intervalMax;
                            if (skill.interval > 0) {
                                if (UIManager.instance.getUI("ButtonSkill" + i).getChildByName("StripBox").getComponent(Sprite).color.a == 0) {
                                    UIManager.instance.getUI("ButtonSkill" + i).getChildByName("StripBox").getComponent(Sprite).color = new Color(0, 0, 0, 105);
                                }
                                UIManager.instance.getUI("ButtonSkill" + i).getChildByName("LabelInterval").getComponent(Label).string = "" + Math.ceil(skill.interval / 60);
                            } else {
                                UIManager.instance.getUI("ButtonSkill" + i).getChildByName("LabelInterval").getComponent(Label).string = "";
                                UIManager.instance.getUI("ButtonSkill" + i).getChildByName("StripBox").getComponent(Sprite).color = new Color(0, 0, 0, 0);
                            }
                            if (player.mp < skill.mp) {
                                UIManager.instance.getUI("ButtonSkill" + i).getChildByName("Mp").getComponent(Sprite).color = this.colorMp[1];
                            } else {
                                UIManager.instance.getUI("ButtonSkill" + i).getChildByName("Mp").getComponent(Sprite).color = this.colorMp[0];
                            }
                        }
                    } else {
                        UIManager.instance.getUI("ButtonSkill" + i).getChildByName("Label").getComponent(Label).string = "";
                        UIManager.instance.getUI("ButtonSkill" + i).getChildByName("Strip").getComponent(Sprite).fillRange = 0;
                        UIManager.instance.getUI("ButtonSkill" + i).getChildByName("Mp").getComponent(Sprite).color = this.colorMp[0];
                    }
                }

                if (player.mp < 20) {
                    UIManager.instance.getUI("JoystickAttack").getChildByName("Rocker").getComponent(Sprite).color = this.colorMp[1];
                } else {
                    UIManager.instance.getUI("JoystickAttack").getChildByName("Rocker").getComponent(Sprite).color = new Color(255, 255, 255, 155);
                }

                if (player.chatCount > 0) {
                    UIManager.instance.getUI("LabelChatInterval").getComponent(Label).string = "冷却中 " + Math.ceil(player.chatCount / 60) + "s";
                } else {
                    if (UIManager.instance.getUI("LabelChatInterval").getComponent(Label).string != "可发言") {
                        UIManager.instance.getUI("LabelChatInterval").getComponent(Label).string = "可发言";
                    }
                }

                for (let playerId in this.pointList) {
                    let point: Node = this.pointList[playerId];
                    let otherPlayer: Node = this.playerList[playerId].node;

                    let posX: number = (otherPlayer.position.x - node.position.x);
                    let posY: number = (otherPlayer.position.y - node.position.y);

                    let viewX: number = (this.viewSize[0] * 0.5) - 30;
                    let viewY: number = (this.viewSize[1] * 0.5) - 30;

                    if (posX < viewX && posX > -viewX && posY < viewY && posY > -viewY) {
                        if (point.getComponent(Sprite).color.a == 255) {
                            point.getComponent(Sprite).color = new Color(255, 155, 115, 0);
                        }
                    } else {
                        if (point.getComponent(Sprite).color.a == 0) {
                            point.getComponent(Sprite).color = new Color(255, 155, 115, 255);
                        }
                    }

                    if (posX < -viewX) {
                        posX = -viewX;
                    }
                    if (posX > viewX) {
                        posX = viewX;
                    }
                    if (posY < -viewY) {
                        posY = -viewY;
                    }
                    if (posY > viewY) {
                        posY = viewY;
                    }

                    point.setPosition(posX, posY);
                }
            }
        }

        for (let id in this.bulletList) {
            let gBullet: gBullet = this.bulletList[id];
            let bullet: lBullet = gBullet.bullet;
            let node: Node = gBullet.node;

            this.lerpMove(bullet, node, attackRate);
        }

        for (let id in this.labelList) {

            // 获取到对象及逻辑
            let gLabel: gLabel = this.labelList[id];
            let label: lLabel = gLabel.label;
            let node: Node = gLabel.node;

            this.lerpMove(label, node, labelRate);
            let scale: number = label.scale * gLabel.scale;
            node.setScale(scale, scale);
        }

        this.showFps(dt);

        this.dtNum += dt;

        if (this.dtNum >= this.fpsNum) {
            let count: number = Math.floor(this.dtNum / this.fpsNum);

            for (let i: number = 0; i < count; i++) {
                this.fixedUpdate();
            }

            this.dtNum -= count * this.fpsNum;
        }
    }

    /**
     * 计算并显示fps
     * @param dt 
     */
    private showFps(dt: number): void {
        this.fpsCount += dt;
        this.fpsValue += 1;
        if (this.fpsCount >= 1) {
            this.fpsCount = 0;
            UIManager.instance.getUI("LabelFps").getComponent(Label).string = "fps:" + this.fpsValue;
            this.fpsValue = 0;
        }
    }

    /**
     * 插值移动
     * @param obj 对象
     * @param node 节点
     * @param rate 速率
     */
    private lerpMove(obj: any, node: Node, rate: number): void {

        let nodeX: number = node.position.x;
        let nodeY: number = node.position.y;

        if (nodeX != obj.x || nodeY != obj.y) {

            // 计算偏移
            let offsetX: number = (obj.x - nodeX) * rate;
            let offsetY: number = (obj.y - nodeY) * rate;

            // 新坐标
            let posX: number = nodeX + offsetX;
            let posY: number = nodeY + offsetY;

            if ((offsetX > 0 && posX > obj.x) || (offsetX < 0 && posX < obj.x)) {
                posX = obj.x;
            }
            if ((offsetY > 0 && posY > obj.y) || (offsetY < 0 && posY < obj.y)) {
                posY = obj.y;
            }

            node.setPosition(posX, posY);
        }
    }

    /**
     * 玩家攻击
     */
    public playerAttack(dx: number, dy: number): void {
        this.addFrame({ cmd: "playerSkill", data: [NetManager.instance.uid_, "开始攻击", 0, [dx, dy]] });
        // console.log("开始攻击");
    }

    /**
     * 玩家停止攻击
     */
    public playerStopAttack(): void {
        this.addFrame({ cmd: "playerSkill", data: [NetManager.instance.uid_, "停止攻击"] });
        // console.log("停止攻击");
    }

    // 玩家技能
    public playerSkill(a: any, b: string): void {
        let index: number = Number(b) + 2;
        this.addFrame({ cmd: "playerSkill", data: [NetManager.instance.uid_, "", index] });
    }

    // 返回主界面
    public backMain(): void {
        NetManager.instance.gameOver();
    }

    // 继续重连
    public reconnect(): void {
        NetManager.instance.reconnectCountClear();
    }

    public sendChatMessage(): void {
        let chatText: string = UIManager.instance.getUI("EditBoxChat").getComponent(EditBox).string;
        if (chatText.length == 0) {
            return;
        }

        // 过滤敏感词
        let filterName: string = Sensitive.instance.filterSensitive(chatText);
        chatText = filterName;
        UIManager.instance.getUI("EditBoxChat").getComponent(EditBox).string = filterName;

        this.addFrame({ cmd: "playerChat", data: [NetManager.instance.uid_, chatText] });
        UIManager.instance.getUI("EditBoxChat").getComponent(EditBox).string = "";

    }

}
