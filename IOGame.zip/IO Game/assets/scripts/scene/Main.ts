
import { _decorator, Component, Node, instantiate, SpriteFrame, Sprite, UITransform, tween, math, EditBox, Label, Toggle, Layout } from 'cc';
import { lSkill } from '../logic/lSkill';
import { GameManager } from '../manager/GameManager';
import { MessageManager } from '../manager/MessageManager';
import { NetManager } from '../manager/NetManager';
import { ResourceManager } from '../manager/ResourceManager';
import { UIManager } from '../manager/UIManager';
import { cmd } from '../tool/cmdClient';
import { ButtonSkill } from '../ui/ButtonSkill';
const { ccclass, property } = _decorator;

type pValue = {
    hpMax: number,
    mpMax: number,
    experienceMax: number,
    attack: number,
};

/**
 * 主界面
 */
@ccclass('Main')
export class Main extends Component {

    public static instance: Main;

    private skillList: { [name: string]: lSkill } = {};
    private playerValueList: { [rank: number]: pValue } = {};

    private skillName: string = "";

    onLoad() {
        Main.instance = this;
    }

    start() {
        this.skillList = GameManager.instance.getSkillList();
        this.playerValueList = GameManager.instance.getPlayerValueList();
    }

    // 创建队组
    public createGroup(): void {
        // console.log("创建队组");
        NetManager.instance.group(0);
    }

    // 加入队组
    public joinGroup(): void {
        // console.log("加入队组");
        NetManager.instance.group(1);
    }

    // 离开队组
    public leaveGroup(): void {
        NetManager.instance.group(2);
    }

    // 踢出队组
    public removeGroup(event: Event, customEventData: string): void {
        console.log(customEventData);
        let removeId: number = Number(customEventData);
        NetManager.instance.group(3, removeId);
    }

    // 开始匹配
    public startMatch(): void {
        console.log("发送开始匹配请求");
        NetManager.instance.match(0);
    }

    // 取消匹配
    public cancelMatch(): void {
        console.log("发送取消匹配请求");
        NetManager.instance.match(1);
    }

    public setPageGift(a: any, b: string): void {
        if (b == "0") {
            UIManager.instance.getUI("PageGift").active = false;
        }
        if (b == "1") {
            UIManager.instance.getUI("PageGift").active = true;
        }
    }

    public setPageSkill(a: any, b: string): void {
        if (b == "0") {
            UIManager.instance.getUI("PageChooseSkill").active = false;
        }
        if (b == "1") {
            UIManager.instance.getUI("PageChooseSkill").active = true;
            this.scheduleOnce(() => {
                let layoutSkill: Node = UIManager.instance.getUI("LayoutChooseSkill");
                if (layoutSkill.children.length == 0) {
                    for (let name in this.skillList) {
                        let node: Node = instantiate(ResourceManager.instance.getObject("ButtonSkill"));
                        node.parent = layoutSkill;
                        node.getChildByName("Label").getComponent(Label).string = name;
                        node.getComponent(ButtonSkill).name_ = name;
                    }
                    UIManager.instance.getUI("ViewChooseSkill").getComponent(UITransform).height = Math.floor(layoutSkill.children.length / 5) * 200 + 80;
                }
            }, 0)
        }
    }

    public showSkillText(name: string): void {
        let skill: lSkill = this.skillList[name];
        this.skillName = name;
        let sText: string = "";
        if (skill.isInput) {
            sText = "主动/" + skill.name + ": " + skill.text + "。" + "魔法消耗: " + skill.mp + "，" + "冷却时间: " + (skill.intervalMax / 60) + "秒。";
        } else {
            if (skill.intervalMax == 0) {
                sText = "被动/" + skill.name + ": " + skill.text + "。";
            } else {
                sText = "被动/" + skill.name + ": " + skill.text + "，间隔时间: " + (skill.intervalMax / 60) + "秒。";
            }
        }
        UIManager.instance.getUI("LabelSkillText").getComponent(Label).string = sText;
    }

    public setSkill(a: any, b: string): void {
        if (b == "0") {
            if (NetManager.instance.skill_.length > 0) {
                NetManager.instance.skill_.splice(NetManager.instance.skill_.length - 1, 1);
            }
        }
        if (b == "1") {
            if (NetManager.instance.skill_.indexOf(this.skillName) == -1) {
                if (NetManager.instance.skill_.length < 4) {
                    if (this.skillList[this.skillName].isInput) {
                        NetManager.instance.skill_.push(this.skillName);
                    } else {
                        let num: number = this.getIsInputNum();
                        if (num < 2) {
                            NetManager.instance.skill_.push(this.skillName);
                        } else {
                            MessageManager.instance.createMessage("最多可携带两个被动技能", 0, 1);
                        }
                    }
                } else {
                    MessageManager.instance.createMessage("技能列表已满", 0, 1);
                }
            } else {
                MessageManager.instance.createMessage("已经携带该技能了", 0, 1);
            }
        }
        // console.log(NetManager.instance.skill_);
        this.updateSkillShow();
    }

    private getIsInputNum(): number {
        let count: number = 0;
        for (let i: number = 0; i < NetManager.instance.skill_.length; i++) {
            let skill: lSkill = this.skillList[NetManager.instance.skill_[i]];
            if (!skill.isInput) {
                count++;
            }
        }
        return count;
    }

    public updateSkillShow(): void {
        for (let i: number = 0; i < 4; i++) {
            let buttonSkill: Node = this.node.getChildByName("ButtonSkill" + i);
            buttonSkill.getChildByName("Label").getComponent(Label).string = "未选择";
        }
        for (let i: number = 0; i < NetManager.instance.skill_.length; i++) {
            let buttonSkill: Node = this.node.getChildByName("ButtonSkill" + i);
            buttonSkill.getChildByName("Label").getComponent(Label).string = NetManager.instance.skill_[i];
        }
    }

    public setPageSet(a: any, b: string): void {
        if (b == "0") {
            UIManager.instance.getUI("PageSet").active = false;
        }
        if (b == "1") {
            UIManager.instance.getUI("PageSet").active = true;
        }
    }

    public setPageValue(a: any, b: string): void {
        if (b == "0") {
            UIManager.instance.getUI("PageValue").active = false;
        }
        if (b == "1") {
            UIManager.instance.getUI("PageValue").active = true;
            this.scheduleOnce(() => {
                let LayoutValue: Node = UIManager.instance.getUI("LayoutValue");
                if (LayoutValue.children.length == 0) {
                    for (let rank in this.playerValueList) {
                        let playerValue: pValue = this.playerValueList[rank];
                        let label: Node = instantiate(ResourceManager.instance.getObject("LabelValue"));
                        label.parent = LayoutValue;
                        label.getComponent(Label).string = "[等级]: " + rank + "， [最大生命]: " + playerValue.hpMax + "， [最大魔法]: " + playerValue.mpMax + "， [攻击力]: " + playerValue.attack + "， [最大经验]: " + playerValue.experienceMax;
                    }

                    let strS: string[] = [
                        "功能介绍 ---------------------------- 功能介绍",
                        "[技能]: 带 * 号 的为被动技能，无法主动释放",
                        "[果实]: [红色果实]: 回复100生命，[蓝色果实]: 回复100魔法，[黄色果实]: 增加100经验",
                        "[等级上限]: 等级最高为15级，满级后/黄色果实将不再增加经验而是回复30点生命值与魔法值",
                        "[击败]: 击败其他玩家随机掉落 红黄蓝果实 数量(3 + 被击败玩家等级 * 2)，最多掉落12个",
                        "[被击败]: 被击败，复活时间(2 + 自身等级)，最多12秒，复活后若等级大于1级，将会降低1级",
                        "[攻击友方]: 攻击友方玩家，将会为其回复 自身攻击力10%加成 的生命值",
                    ];

                    for (let i: number = 0; i < strS.length; i++) {
                        let label: Node = instantiate(ResourceManager.instance.getObject("LabelValue"));
                        label.parent = LayoutValue;
                        label.getComponent(Label).string = strS[i];
                        // console.log(strS[i]);
                    }

                    UIManager.instance.getUI("LayoutValueView").getComponent(UITransform).height = LayoutValue.children.length * 70;
                }
            }, 0)
        }
    }

    public setGameSet(a: any, b: string): void {
        if (b == "固定摇杆") {
            if (UIManager.instance.getUI("ToggleJoystick").getComponent(Toggle).isChecked) {
                NetManager.instance.joystickType = 1;

            } else {
                NetManager.instance.joystickType = 0;
            }
            // console.log(NetManager.instance.joystickType);
        }
    }

    public startGift(): void {
        if (NetManager.instance.gift_ == 0) {
            MessageManager.instance.createMessage("今日次数已用完", 0, 1);
            return;
        }
        NetManager.instance.startGift();
        // let giftNode: Node = UIManager.instance.getUI("GiftNode");
        // // giftNode.angle += 45;
        // let angle: number = 720;
        // let giftIndex: number = Math.round(Math.random() * 7);
        // angle += giftIndex * 45;
        // tween(giftNode)
        //     .to(2.2, { angle: giftNode.angle + angle })
        //     .start()
    }

    public updateGift(giftId: number): void {

        let GiftPointer: Node = UIManager.instance.getUI("GiftPointer");
        GiftPointer.angle = 0;
        // giftNode.angle += 45;
        let angle1: number = 1800;
        let angle2: number = 720;
        // let giftId: number = Math.round(Math.random() * 7);
        let angle3: number = giftId * 45;
        tween(GiftPointer)
            .to(1.5, { angle: GiftPointer.angle - angle1 })
            .call(() => {
                tween(GiftPointer)
                    .to(1, { angle: GiftPointer.angle - angle2 })
                    .call(() => {
                        tween(GiftPointer)
                            .to(0.5, { angle: GiftPointer.angle - angle3 })
                            .call(() => {
                                NetManager.instance.updateUserShow();
                            })
                            .start()
                    })
                    .start()
            })
            .start()
    }

    // 退出登录
    public quitLogin(): void {
        // console.log("退出登录");
        NetManager.instance.quitLogin();
    }

    // 复制小队码
    public copyGroupId(): void {
        GameManager.instance.copyToClipboard("" + NetManager.instance.groupId_);
        MessageManager.instance.createMessage("复制小队码成功");
    }

    // 读取复制的小队码
    public readCopyGroupId(): void {
        GameManager.instance.getCopyText();
    }

    // 清除小队码
    public clearGroupId(): void {
        UIManager.instance.getUI("EditBoxGroupId").getComponent(EditBox).string = "";
    }

    // 打开应用
    public openApp(a: any, b: string): void {
        let type: number = Number(b);
        let url: string = "";
        // QQ
        if (type == 1) {
            url = `mqqwpa://im/chat?chat_type=wpa&uin= &version=1`;
        }
        // 微信
        if (type == 2) {
            url = "weixin://";
        }
        GameManager.instance.openApp(url);
    }

}
