
import { _decorator, Vec2 } from 'cc';
import { lBullet } from '../logic/lBullet';
import { lAudio } from '../logic/lAudio';
import { lFruit } from '../logic/lFruit';
import { lLabel } from '../logic/lLabel';
import { lMessage } from '../logic/lMessage';
import { lPlayer } from '../logic/lPlayer';
import { Game } from './Game';
import { lSkill } from '../logic/lSkill';

/**
 * 帧数据
 */
type Frame = {
    cmd: string,
    data: any[]
};

/**
 * 碰撞类
 */
type Collide = {
    /**
     * x坐标
     */
    x: number,
    /**
     * y坐标
     */
    y: number,
    /**
     * 宽度
     */
    width: number,
    /**
     * 高度
     */
    height: number
}

type pValue = {
    hpMax: number,
    mpMax: number,
    experienceMax: number,
    attack: number,
};

/**
 * 技能计数类
 */
type SkillCount = {
    name: string,
    count: number,
};

/**
 * 逻辑层管理类
 */
export class Logic {

    /**
     * 逻辑层管理器
     */
    public static instance: Logic;

    public frameRate: number = 60; // 逻辑帧率


    private skillList: { [name: string]: lSkill } = {};

    private playerValueList: { [rank: number]: pValue } = {};

    private seed: number = 999; // 随机数种子

    private fpsNum: number = 1 / 64; // 执行数据 帧率
    private dtNum: number = 0; // 计数

    private frameList: Frame[][] = []; // 帧数据列表
    private frameIndex: number = 0; // 帧索引

    private playerList: lPlayer[] = []; // 玩家列表

    private bulletList: lBullet[] = []; // 子弹列表

    private fruitList: lFruit[] = []; // 果实列表

    private labelList: lLabel[] = []; // 文本列表

    private audioList: lAudio[] = []; // 音频列表

    private messageList: lMessage[] = []; // 消息列表

    private collideList: Collide[] = []; // 碰撞列表

    private bulletSize: number = 60;
    private bulletOffset: number = this.bulletSize / 2;

    private map0: Collide[] = [{ "x": -405, "y": 660, "width": 556, "height": 48 }, { "x": 405, "y": 660, "width": 556, "height": 48 }, { "x": -659, "y": 0, "width": 48, "height": 1275 }, { "x": 659, "y": 0, "width": 48, "height": 1275 }, { "x": 0, "y": -660, "width": 1366, "height": 48 }, { "x": -320, "y": 32, "width": 360, "height": 50 }, { "x": 320, "y": 32, "width": 360, "height": 50 }, { "x": -320, "y": -355, "width": 370, "height": 55 }, { "x": 320, "y": -355, "width": 370, "height": 55 }, { "x": -320, "y": -160, "width": 240, "height": 40 }, { "x": 320, "y": -160, "width": 240, "height": 40 }];

    private teamPos: { [id: number]: number[] } = {
        [1]: [0, 1000],
        [2]: [-1000, -1000],
        [3]: [1000, -1000]
    }

    // 队伍分数列表
    private teamValues: { [id: number]: number } = {
        [1]: 0,
        [2]: 0,
        [3]: 0
    };

    private Labelcolors: { [name: string]: number[] } = {
        ["-hp"]: [255, 0, 0, 255, 1],
        ["+hp"]: [0, 255, 0, 255, 1],
        ["+mp"]: [0, 255, 255, 255, 1],
        ["beat"]: [255, 0, 0, 255, 2.5],
    };

    private gameTime: number = 6 * 60; // 游戏时间
    private timeCount: number = 0; // 时间计数

    private fruitTime: number = 0; // 果实生成时间计数
    private fruitMaxTime: number = 60 * 6; // 果实生成时间

    private id: number = 0; // 唯一id

    private mapWidth: number = 3200; // 地图宽度
    private mapHeight: number = 3200; // 地图高度
    private mapX: number = 0; // 地图 1/2 X
    private mapY: number = 0; // 地图 1/2 Y

    private robotUpdateCount: number = 0;
    private robotmoveCount: number = 0;

    constructor(skillList: { [name: string]: lSkill }, playerValueList: { [rank: number]: pValue }) {
        Logic.instance = this;

        this.mapX = this.mapWidth / 2;
        this.mapY = this.mapHeight / 2;

        this.collideList = this.map0;

        this.skillList = skillList;
        this.playerValueList = playerValueList;
    }

    /**
     * 收到数据帧
     * @param frameData 数据
     */
    public addFrame(frameData: Frame[]): void {
        this.frameList.push(frameData);
    }

    // 驱动帧循环
    private actuatedFrame(): void {
        let frameCount: number = this.frameList.length - this.frameIndex;
        // console.log("frameCount: " + frameCount);

        if (frameCount > 100) {
            for (let i: number = 0; i < 100; i++) {
                this.executeFrame();
            }
        } else {
            if (frameCount > 50) {
                for (let i: number = 0; i < 50; i++) {
                    this.executeFrame();
                }
            } else {
                if (frameCount > 1) {
                    for (let i: number = 0; i < frameCount; i++) {
                        this.executeFrame();
                    }
                } else {
                    this.executeFrame();
                }
            }
        }

        // frameCount = this.frameList.length - this.frameIndex;
        // console.log("frameCount: " + (this.frameList.length - this.frameIndex));
    }

    // 执行帧指令
    private executeFrame(): void {

        if (this.gameTime == 0) {
            return;
        }

        if (this.frameIndex == this.frameList.length) {
            return;
        }

        for (let i: number = 0; i < this.frameList[this.frameIndex].length; i++) {
            let frame: Frame = this.frameList[this.frameIndex][i];
            this[frame.cmd](frame.data);
        }

        this.frameIndex++;

        this.updateData();
    }

    // 设置随机数种子
    private setSeed(msg: any[]): void {
        let data: { seed: number } = {
            seed: msg[0],
        };

        this.seed = data.seed;

        for (let i: number = 0; i < 120; i++) {
            this.createRandomFruit();
        }

    }


    private createRandomFruit(): void {
        let type: number = -1;
        let s: number = this.random(18);
        if (s < 1) {
            type = 0;
        } else {
            if (s < 4) {
                type = 1;
            } else {
                type = 2;
            }
        }
        this.createFruit(type, this.randomRange(-1500, 1500), this.randomRange(-1500, 1500), 32, 32);
    }

    // 设置玩家向量
    private setVector(msg: any[]): void {
        let data: { id: number, vectorX: number, vectorY: number } = {
            id: msg[0],
            vectorX: msg[1],
            vectorY: msg[2]
        };

        let player: lPlayer = this.getPlayer(data.id);
        if (player.reStartCount > 0) {
            return;
        }

        player.vectorX = data.vectorX;
        player.vectorY = data.vectorY;

        // if (data.vectorX == 0 && data.vectorY == 0) {
        //     return;
        // }

        // player.angleX = data.vectorX;
        // player.angleY = data.vectorY;

        // console.log("setVector", data);
    }

    private setRobotVector(player: lPlayer, dirX: number, dirY: number): void {
        let dir: { x: number, y: number } = this.getVector(dirX, dirY);
        this.setVector([player.id, dir.x, dir.y]);
    }

    private setRobotRandomVector(player: lPlayer): void {
        let dirX: number = this.randomRange(-80, 80);
        let dirY: number = this.randomRange(-80, 80);
        this.setRobotVector(player, dirX, dirY);
    }

    // private getSkill0(name: string): lSkill {
    //     return this.skillList0[name];
    // }

    // private getSkill1(name: string): lSkill {
    //     return this.skillList1[name];
    // }

    // 创建玩家
    private createPlayer(msg: any[]): void {
        let data: { id: number, name: string, isRobot: boolean, userId: number, teamId: number, skills: string[] } = {
            id: msg[0],
            name: msg[1],
            isRobot: msg[2],
            userId: msg[3],
            teamId: msg[4],
            skills: msg[5],
        };

        let player: lPlayer = new lPlayer(data.id, data.name, data.isRobot, data.userId, data.teamId);
        // player.x = 0;
        // player.y = 0;
        player.x = this.teamPos[player.teamId][0];
        player.y = this.teamPos[player.teamId][1];

        player.setSkill(new lSkill("开始攻击", 0, 0, true, ""));
        player.setSkill(new lSkill("停止攻击", 0, 0, true, ""));

        if (!player.isRobot) {
            for (let i: number = 0; i < data.skills.length; i++) {
                let name: string = data.skills[i];
                player.setSkill(this.getSkill(name));
            }
        } else {
            player.setSkill(this.getSkill("闪烁"));
            player.setSkill(this.getSkill("飞弹术"));
            player.setSkill(this.getSkill("狂暴"));
            player.setSkill(this.getSkill("吸血术"));
        }

        this.playerUpgrade(player);
        this.playerUpdateValue(player);

        this.playerList.push(player);

        if (player.isRobot) {
            this.setRobotRandomVector(player);
        }

        // console.log("createPlayer", data);
    }

    private getSkill(name: string): lSkill {
        return this.skillList[name];
    }

    /**
     * 创建消息
     * @param value 消息内容
     * @param type 消息类型
     */
    private createMessage(value: string, type: number): void {
        let message: lMessage = new lMessage(this.getId(), type, value);
        this.messageList.push(message);
    }

    /**
     * 创建文本
     * @param value 文本内容
     * @param colorName 文本颜色名称
     * @param x 文本x坐标
     * @param y 文本y坐标
     */
    private createLabel(value: string, colorName: string, x: number, y: number): void {
        let color: number[] = this.Labelcolors[colorName];
        let label: lLabel = new lLabel(this.getId(), value, [color[0], color[1], color[2], color[3]], x, y);
        label.scale = color[4];
        this.labelList.push(label);
    }

    /**
     * 创建果实
     * @param type 果实类型
     * @param x 果实x坐标
     * @param y 果实y坐标
     */
    private createFruit(type: number, x: number, y: number, width: number, height: number, name?: string): void {
        let fruit: lFruit = new lFruit(this.getId(), type, x, y, width, height);
        if (name != undefined) {
            fruit.name = name;
        }
        this.objCollisionMap(fruit);
        this.fruitList.push(fruit);
    }

    /**
     * 创建音效
     * @param name 音效名称
     * @param x 音效x坐标
     * @param y 音效y坐标
     */
    private createAudio(name: string, x: number, y: number): void {
        let audio: lAudio = new lAudio(this.getId(), name, x, y);
        this.audioList.push(audio);
    }


    private playerUpdateHp(player: lPlayer, state: string, value: number): void {
        if (state == "+") {
            let hpValue: number = value;
            if (player.getSkill("不死血统") != undefined) {
                hpValue = Math.ceil(this.mul(value, 1.25));
            }
            player.hp = this.add(player.hp, hpValue);
            this.createLabel("" + hpValue, "+hp", player.x, player.y);
        }
        if (state == "-") {
            player.hp = this.sub(player.hp, value);
            this.createLabel("" + value, "-hp", player.x, player.y);
        }
    }

    private playerUpdateMp(player: lPlayer, state: string, value: number): void {
        if (state == "+") {
            player.mp = this.add(player.mp, value);
        }
        if (state == "-") {
            let mpValue: number = value;
            if (player.getSkill("魔泉") != undefined) {
                mpValue = Math.ceil(this.mul(value, 0.85));
            }
            player.mp = this.sub(player.mp, mpValue);
        }
    }

    private playerStartAttack(player: lPlayer): void {

        if (player.attackInterval > 0) {
            return;
        }

        if (player.mp < 20) {
            return;
        }

        this.playerUpdateMp(player, "-", 20);
        player.attackInterval = player.attackMaxInterval;

        let posX: number = this.add(player.x, this.mul(player.angleX, this.bulletOffset));
        let posY: number = this.add(player.y, this.mul(player.angleY, this.bulletOffset));
        this.createBullet(player, player.attack, posX, posY, this.bulletSize, this.bulletSize, player.angleX, player.angleY);

        let skillCount0: SkillCount = player.getSkillCount("飞弹术");
        if (skillCount0.count > 0) {
            for (let i: number = 0; i < 2; i++) {
                let dirX: number = this.randomRange(-80, 80);
                let dirY: number = this.randomRange(-80, 80);
                let vector: { x: number, y: number } = this.getVector(dirX, dirY);

                this.createBullet(player, Math.ceil(this.mul(player.attack, 0.5)), posX, posY, Math.ceil(this.mul(this.bulletSize, 0.5)), Math.ceil(this.mul(this.bulletSize, 0.5)), vector.x, vector.y);
            }
        }

        let skillCount1: SkillCount = player.getSkillCount("魔飞弹术");
        if (skillCount1.count > 0) {
            for (let i: number = 0; i < 5; i++) {
                let dirX: number = this.randomRange(-80, 80);
                let dirY: number = this.randomRange(-80, 80);
                let vector: { x: number, y: number } = this.getVector(dirX, dirY);

                this.createBullet(player, Math.ceil(this.mul(player.attack, 0.3)), posX, posY, Math.ceil(this.mul(this.bulletSize, 0.3)), Math.ceil(this.mul(this.bulletSize, 0.3)), vector.x, vector.y);
            }
        }

        let skillCount2: SkillCount = player.getSkillCount("双向弹");
        if (skillCount2.count > 0) {
            this.createBullet(player, Math.ceil(this.mul(player.attack, 0.5)), posX, posY, Math.ceil(this.mul(this.bulletSize, 0.6)), Math.ceil(this.mul(this.bulletSize, 0.6)), -player.angleX, -player.angleY);
        }

        this.createAudio("attack", player.x, player.y);
    }

    /**
     * 创建子弹
     * @param player 
     * @param pAttack 
     * @param posX 
     * @param posY 
     * @param vectorX 
     * @param vectorY 
     */
    private createBullet(player: lPlayer, attack: number, posX: number, posY: number, width: number, height: number, vectorX: number, vectorY: number): void {
        let id: number = this.getId();
        let bullet: lBullet = new lBullet(id, player.id, player.userId, player.teamId, "子弹", posX, posY, width, height, vectorX, vectorY, 40);
        bullet.attack = attack;
        if (player.getSkill("近身战") != undefined) {
            bullet.attack = Math.ceil(this.mul(bullet.attack, 1.1));
            bullet.count = Math.ceil(this.mul(bullet.count, 0.25));
            bullet.width = Math.ceil(this.mul(bullet.width, 1.9));
            bullet.height = Math.ceil(this.mul(bullet.height, 1.9));
        }
        if (player.getSkill("狙击手") != undefined) {
            bullet.attack = Math.ceil(this.mul(bullet.attack, 0.7));
            bullet.count = Math.ceil(this.mul(bullet.count, 1.5));
            bullet.width = Math.ceil(this.mul(bullet.width, 0.8));
            bullet.height = Math.ceil(this.mul(bullet.height, 0.8));
        }
        if (player.getSkillCount("持久弹").count > 0) {
            bullet.count = Math.ceil(this.mul(bullet.count, 1.5));
        }
        if (player.getSkillCount("穿透弹").count > 0) {
            bullet.type = "穿透弹";
        }
        if (player.getSkillCount("巨型弹").count > 0) {
            bullet.attack = Math.ceil(this.mul(attack, 1.2));
            bullet.width = Math.ceil(this.mul(bullet.width, 1.5));
            bullet.height = Math.ceil(this.mul(bullet.height, 1.5));
        }
        this.bulletList.push(bullet);
    }

    // 玩家治疗
    private playerHeal(msg: any[]): void {
        let data: { id: number } = {
            id: msg[0],
        };

        let player: lPlayer = this.getPlayer(data.id);
        // if (player.reStartCount > 0) {
        //     return;
        // }
        // if (player.healInterval > 0) {
        //     return;
        // }
        // if (player.hp == player.hpMax && player.mp == player.mpMax) {
        //     return;
        // }
        // player.healInterval = player.healMaxInterval;
        // 回复 20% 血量 和 能量 (向上取整)+
        let hpValue: number = Math.ceil(this.mul(player.hpMax, 0.2));
        let mpValue: number = Math.ceil(this.mul(player.mpMax, 0.2));
        this.playerUpdateHp(player, "+", hpValue);
        this.playerUpdateMp(player, "+", mpValue);
        this.playerUpdateValue(player);

        this.createAudio("heal", player.x, player.y);
    }

    // 玩家释放技能
    private playerSkill(msg: any[]): void {
        let data: { id: number, name: string, index?: number, data?: any[] } = {
            id: msg[0],
            name: msg[1],
            index: msg[2],
            data: msg[3],
        };

        let player: lPlayer = this.getPlayer(data.id);
        let skill: lSkill = undefined;
        if (data.name != "") {
            skill = player.getSkill(data.name);
        } else {
            skill = player.getISkill(data.index);
        }

        if (skill == undefined) {
            return;
        }
        if (!skill.isInput) {
            return;
        }
        if (skill.interval > 0) {
            return;
        }
        if (player.mp < skill.mp) {
            return;
        }

        this.playerUpdateMp(player, "-", skill.mp);

        let sName: string = skill.name;
        if (sName == "开始攻击") {
            player.isAttack = true;
            let dirX: number = data.data[0];
            let dirY: number = data.data[1];
            player.angleX = dirX;
            player.angleY = dirY;
            // console.log(dirX, dirY);
        }
        if (sName == "停止攻击") {
            player.isAttack = false;
        }

        if (sName != "开始攻击" && sName != "停止攻击") {
            this.createLabel(sName, "-hp", player.x, player.y);
        }

        if (sName == "闪烁") {
            // 立刻到达 指定方向 * 250码 坐标
            let vectorX: number = player.vectorX;
            let vectorY: number = player.vectorY;
            if (vectorX == 0 && vectorY == 0) {
                vectorX = player.angleX;
                vectorY = player.angleY;
            }
            let posX: number = this.mul(vectorX, 240);
            let posY: number = this.mul(vectorY, 240);
            player.x = this.add(player.x, posX);
            player.y = this.add(player.y, posY);
            this.objCollisionMap(player);

            this.createAudio("skillb", player.x, player.y);
        }
        if (sName == "治疗术") {
            // 回复 25% 最大血量和魔法
            let hpValue: number = Math.ceil(this.mul(player.hpMax, 0.25));
            let mpValue: number = Math.ceil(this.mul(player.mpMax, 0.25));
            this.playerUpdateHp(player, "+", hpValue);
            this.playerUpdateMp(player, "+", mpValue);
            this.playerUpdateValue(player);

            this.createAudio("heal", player.x, player.y);
        }
        if (sName == "飞弹术") {
            // 攻击时 随机方向发射两枚飞弹
            let skillCount: SkillCount = player.getSkillCount(sName);
            skillCount.count = 5 * this.frameRate;
        }
        if (sName == "魔飞弹术") {
            // 攻击时 随机方向发射三枚飞弹
            let skillCount: SkillCount = player.getSkillCount(sName);
            skillCount.count = 5 * this.frameRate;
        }
        if (sName == "空间穿梭") {
            // 随机穿梭至一个位置并获取1秒护盾
            player.x = this.randomRange(-1500, 1500);
            player.y = this.randomRange(-1500, 1500);
            player.getSkillCount("能量护盾").count = this.frameRate * 1;
        }
        if (sName == "能量护盾") {
            // 
            player.getSkillCount("能量护盾").count = this.frameRate * 2;
        }
        if (sName == "虚无术") {
            let skillCount: SkillCount = player.getSkillCount(sName);
            skillCount.count = 4 * this.frameRate;
        }
        if (sName == "魔法飞弹") {
            this.createBullet(player, this.mul(player.attack, 2), player.x + this.mul(player.angleX, this.mul(this.bulletOffset, 2)), player.y + this.mul(player.angleY, this.mul(this.bulletOffset, 2)), Math.ceil(this.mul(this.bulletSize, 2.4)), Math.ceil(this.mul(this.bulletSize, 2.4)), player.angleX, player.angleY);
        }
        if (sName == "吸血术") {
            let skillCount: SkillCount = player.getSkillCount(sName);
            skillCount.count = 5 * this.frameRate;
        }
        if (sName == "高速滑轮") {
            let skillCount: SkillCount = player.getSkillCount(sName);
            skillCount.count = 4 * this.frameRate;
        }
        if (sName == "狂暴") {
            let skillCount: SkillCount = player.getSkillCount(sName);
            skillCount.count = 5 * this.frameRate;
            player.attackMaxInterval = 15;
        }
        if (sName == "穿透弹") {
            let skillCount: SkillCount = player.getSkillCount(sName);
            skillCount.count = 5 * this.frameRate;
        }
        if (sName == "持久弹") {
            let skillCount: SkillCount = player.getSkillCount(sName);
            skillCount.count = 5 * this.frameRate;
        }
        if (sName == "巨型弹") {
            let skillCount: SkillCount = player.getSkillCount(sName);
            skillCount.count = 5 * this.frameRate;
        }
        if (sName == "双向弹") {
            let skillCount: SkillCount = player.getSkillCount(sName);
            skillCount.count = 5 * this.frameRate;
        }

        skill.interval = skill.intervalMax;
    }

    // 玩家聊天
    private playerChat(msg: any[]): void {
        let data: { id: number, text: string } = {
            id: msg[0],
            text: msg[1]
        };

        let player: lPlayer = this.getPlayer(data.id);

        if (player.chatCount > 0) {
            return;
        }
        player.chatText = data.text;
        player.chatCount = this.frameRate * 6;
    }

    /**
     * 玩家属性更新
     * @param player 玩家对象
     */
    private playerUpgrade(player: lPlayer): void {

        let rank: number = player.rank;
        let value: pValue = this.playerValueList[rank];

        player.hpMax = value.hpMax;
        player.mpMax = value.mpMax;
        player.experienceMax = value.experienceMax;
        player.attack = value.attack;
        if (player.rank == 1) {
            player.hp = player.hpMax;
            player.mp = player.mpMax;
        }
    }

    /**
     * 玩家更新属性
     * @param player 玩家对象
     */
    private playerUpdateValue(player: lPlayer): void {
        if (player.hp > player.hpMax) {
            player.hp = player.hpMax;
        }
        if (player.mp > player.mpMax) {
            player.mp = player.mpMax;
        }
    }

    /**
     * 玩家被击败
     */
    private playerBeat(player: lPlayer, otherPlayer: lPlayer, bullet: lBullet): void {
        this.createLabel("击败", "beat", player.x, player.y);
        this.createAudio("beat", player.x, player.y);
        this.playerReStart(player);
        // 队伍分数++
        this.teamValues[otherPlayer.teamId] += 100;
        // console.log(player.name + " 被 " + this.getPlayer(attack.parentId).name + "击败");
        this.createMessage(this.getPlayer(bullet.parentId).name + " /击败/ " + player.name, 1);
    }

    /**
     * 玩家复活
     */
    private playerReStart(player: lPlayer): void {

        let rank: number = player.rank;

        // 复活时间
        let count: number = 2 + rank;
        if (count > 12) {
            count = 12;
        }

        // 掉落果实数量
        let fruitNum: number = (3 + rank * 2);
        if (fruitNum > 12) {
            fruitNum = 12;
        }

        this.playerUpgrade(player);

        player.hp = player.hpMax;
        player.mp = player.mpMax;

        let posX: number = player.x;
        let posY: number = player.y;

        player.reStartCount = this.frameRate * count;
        player.x = -100000;
        player.y = -100000;

        for (let i: number = 0; i < fruitNum; i++) {
            let type: number = Math.round(this.random(2));
            this.createFruit(type, posX + this.randomRange(-120, 120), posY + this.randomRange(-120, 120), 32, 32);
        }

        // 降1级
        if (player.getSkill("斗争心") == undefined) {
            if (player.rank > 1) {
                player.rank -= 1;
                this.playerUpgrade(player);
            }
        }
    }

    // 数据更新
    private updateData(): void {

        this.updateMessage();
        this.updateAudio();
        this.updateLabel();
        this.updateBullet();
        this.updateRobot();
        this.updatePlayer();
        this.updateFruit();
        this.updateTime();

        let frameCount: number = this.frameList.length - this.frameIndex;
        if (frameCount < 15) {
            Game.instance.updateGame({ players: this.playerList, bullets: this.bulletList, fruits: this.fruitList, teamValues: this.teamValues, labels: this.labelList, audios: this.audioList, messages: this.messageList, time: this.gameTime });
        }
    }

    /**
     * 更新消息数据
     */
    private updateMessage(): void {
        for (let i: number = 0; i < this.messageList.length; i++) {
            let message: lMessage = this.messageList[i];

            message.count++;
            if (message.count == 150) {
                this.messageList.splice(i, 1);
            }
        }
    }

    /**
     * 更新音效数据
     */
    private updateAudio(): void {
        for (let i: number = 0; i < this.audioList.length; i++) {
            let audio: lAudio = this.audioList[i];
            if (audio.count == 1) {
                this.audioList.splice(i, 1);
            } else {
                audio.count++;
            }
        }
    }

    /**
     * 更新文本数据
     */
    private updateLabel(): void {
        for (let i: number = 0; i < this.labelList.length; i++) {
            let label: lLabel = this.labelList[i];

            label.count++;
            label.y = this.add(label.y, 6);
            // label.scale = this.sub(label.scale, 0.035);
            if (label.count == 24) {
                this.labelList.splice(i, 1);
            }
        }
    }

    /**
     * 更新子弹数据
     */
    private updateBullet(): void {
        for (let i: number = 0; i < this.bulletList.length; i++) {
            let bullet: lBullet = this.bulletList[i];
            let speed: number = 12;
            let vectorX: number = this.mul(bullet.vectorX, speed);
            let vectorY: number = this.mul(bullet.vectorY, speed);
            bullet.x = this.add(bullet.x, vectorX);
            bullet.y = this.add(bullet.y, vectorY);
            bullet.count -= 1;

            if (bullet.type != "穿透弹") {
                if (this.isCollide({ x: bullet.x, y: bullet.y, width: bullet.width, height: bullet.height })) {
                    if (bullet.count > 4) {
                        bullet.count = 4;
                    }
                }
            }

            if (bullet.count == 0) {
                this.bulletList.splice(i, 1);
            }
        }
    }

    /**
     * 更新机器人数据
     */
    private updateRobot(): void {
        this.robotUpdateCount++;
        this.robotmoveCount++;
        if (this.robotUpdateCount == 20) {
            this.robotUpdateCount = 0;
            for (let i: number = 0; i < this.playerList.length; i++) {
                let player: lPlayer = this.playerList[i];
                // 是机器人
                if (player.isRobot) {
                    // 不是复活状态
                    if (player.reStartCount == 0) {

                        let sValue: number = this.random(64);
                        if (sValue < 58) {
                            // 处理移动
                            if (this.robotmoveCount == 60) {

                                if (this.random(32) < 26) {
                                    // 计算非同队伍的距离列表
                                    let distancePlayers: { player: lPlayer, distance: number }[] = [];
                                    for (let j: number = 0; j < this.playerList.length; j++) {
                                        let otherPlayer: lPlayer = this.playerList[j];
                                        if (otherPlayer.teamId != player.teamId) {
                                            let distance: number = this.distance(player.x, player.y, otherPlayer.x, otherPlayer.y);
                                            if (distance < this.randomRange(800, 1200)) {
                                                distancePlayers.push({ player: otherPlayer, distance: distance });
                                            }
                                        }
                                    }

                                    if (distancePlayers.length > 0) {
                                        // 排序--->
                                        distancePlayers.sort((a: { player: lPlayer, distance: number }, b: { player: lPlayer, distance: number }) => {
                                            return a.distance - b.distance;
                                        })

                                        // console.log(distancePlayers);
                                        // 获取最近距离其他玩家
                                        let otherPlayer: lPlayer = distancePlayers[0].player;

                                        let dirX: number = this.sub(otherPlayer.x, player.x);
                                        let dirY: number = this.sub(otherPlayer.y, player.y);

                                        this.setRobotVector(player, dirX, dirY);
                                    } else {
                                        if (this.random(12) < 8) {
                                            this.setRobotRandomVector(player);
                                        }
                                    }
                                } else {
                                    this.setRobotRandomVector(player);
                                }

                                // 处理技能释放
                                {
                                    if (this.random(24) < 4) {
                                        this.playerSkill([player.id, "闪烁"]);
                                    }
                                    if (this.random(32) < 8) {
                                        if (player.skillList.length > 2) {
                                            this.playerSkill([player.id, "", 3]);
                                        }
                                    }
                                }
                            }

                            // 处理攻击
                            {
                                if (this.random(32) < 21) {
                                    let isAttack: boolean = false;
                                    for (let j: number = 0; j < this.playerList.length; j++) {
                                        let otherPlayer: lPlayer = this.playerList[j];
                                        if (otherPlayer.teamId != player.teamId) {
                                            let playerObj: Collide = { x: this.add(player.x, this.mul(player.angleX, 50)), y: this.add(player.y, this.mul(player.angleY, 50)), width: 100, height: 100 };
                                            let otherplayerObj: Collide = { x: otherPlayer.x, y: otherPlayer.y, width: otherPlayer.width * 2, height: otherPlayer.height * 2 };
                                            if (this.collisionCircular(playerObj, otherplayerObj)) {
                                                isAttack = true;
                                            }
                                        }
                                    }
                                    if (isAttack) {
                                        this.playerSkill([player.id, "开始攻击", 0, [player.vectorX, player.vectorY]]);
                                    } else {
                                        if (this.random(6) < 5) {
                                            this.playerSkill([player.id, "停止攻击"]);
                                        }
                                    }
                                } else {
                                    if (this.random(6) < 3) {
                                        this.playerSkill([player.id, "停止攻击"]);
                                    }
                                }
                            }

                        } else {
                            if (this.random(3) < 1) {
                                this.setRobotRandomVector(player);
                            }
                        }
                    }
                }
            }
        }

        if (this.robotmoveCount == 60) {
            this.robotmoveCount = 0;
        }
    }

    /**
     * 更新玩家数据
     */
    private updatePlayer(): void {
        for (let i: number = 0; i < this.playerList.length; i++) {
            let player: lPlayer = this.playerList[i];

            // 处理攻击冷却
            if (player.attackInterval > 0) {
                player.attackInterval -= 1;
            }

            // 处理技能冷却
            for (let j: number = 0; j < player.skillList.length; j++) {
                let skill: lSkill = player.skillList[j];
                if (skill.interval > 0) {
                    skill.interval -= 1;
                }
            }

            // 处理技能计数
            for (let j: number = 0; j < player.skillCountList.length; j++) {
                let skillCount: SkillCount = player.skillCountList[j];
                if (skillCount.count > 0) {
                    skillCount.count -= 1;
                    // 计数结束
                    if (skillCount.count == 0) {
                        let sName: string = skillCount.name;
                        if (sName == "狂暴") {
                            player.attackMaxInterval = 20;
                        }
                    }
                }
            }

            // 处理聊天冷却
            if (player.chatCount > 0) {
                player.chatCount -= 1;
            }

            // 处理技能0
            let skill0: lSkill = player.getSkill("血液循环");
            if (skill0 != undefined) {
                if (skill0.interval == 0) {
                    skill0.interval = skill0.intervalMax;
                    this.playerUpdateHp(player, "+", Math.ceil(this.mul(player.hpMax, 0.06)));
                }
            }

            player.mpInterval += 1;
            if (player.mpInterval == player.mpMaxInterval) {
                player.mpInterval = 0;
                if (player.mp < player.mpMax) {
                    this.playerUpdateMp(player, "+", player.mpValue);
                    this.playerUpdateValue(player);
                }
            }

            if (player.reStartCount > 0) {
                player.reStartCount -= 1;
                // 玩家复活
                if (player.reStartCount == 0) {

                    player.x = this.randomRange(-1500, 1500);
                    player.y = this.randomRange(-1500, 1500);

                    player.angleX = 0;
                    player.angleY = -1;
                    player.vectorX = 0;
                    player.vectorY = 0;

                    player.getSkillCount("能量护盾").count = this.frameRate * 2;

                    if (player.isRobot) {
                        this.setRobotRandomVector(player);
                    }
                }
            }

            if (player.reStartCount == 0) {

                let speed: number = player.speed;
                if (player.getSkillCount("高速滑轮").count > 0) {
                    speed = Math.ceil(this.mul(speed, 1.5));
                }
                let vectorX: number = this.mul(player.vectorX, speed);
                let vectorY: number = this.mul(player.vectorY, speed);

                player.x = this.add(player.x, vectorX);
                player.y = this.add(player.y, vectorY);

                this.objCollisionMap(player);

                let skillCount0: SkillCount = player.getSkillCount("虚无术");
                if (skillCount0.count == 0) {
                    this.collidePhysics(player);
                }

                // 攻击
                if (player.isAttack) {
                    this.playerStartAttack(player);
                }

                // 实体碰撞体
                let collide0: Collide = {
                    x: player.x,
                    y: player.y,
                    width: player.width,
                    height: player.height
                };

                // 果实碰撞体
                let collide1: Collide = {
                    x: player.x,
                    y: player.y,
                    width: Math.ceil(player.width * 1.5),
                    height: Math.ceil(player.height * 1.5)
                };

                // 处理果实碰撞
                for (let j: number = 0; j < this.fruitList.length; j++) {
                    let fruit: lFruit = this.fruitList[j];

                    let collide2: Collide = {
                        x: fruit.x,
                        y: fruit.y,
                        width: fruit.width,
                        height: fruit.height
                    };

                    if (this.collisionCircular(collide1, collide2)) {
                        let isEat: boolean = true;

                        let fType: number = fruit.type;

                        // 回复血量
                        if (fType == 0) {
                            if (player.hp != player.hpMax) {
                                this.playerUpdateHp(player, "+", 100);
                                this.playerUpdateValue(player);
                            } else {
                                isEat = false;
                            }
                        }
                        // 回复能量
                        if (fType == 1) {
                            if (player.mp != player.mpMax) {
                                this.playerUpdateMp(player, "+", 100);
                                this.playerUpdateValue(player);
                            } else {
                                isEat = false;
                            }
                        }
                        // 增加经验
                        if (fType == 2) {
                            if (player.rank < 15) {
                                player.experience += 100;
                                if (player.experience >= player.experienceMax) {
                                    player.experience -= player.experienceMax;
                                    player.rank += 1;
                                    this.playerUpgrade(player);
                                }
                            } else {
                                this.playerUpdateHp(player, "+", 30);
                                this.playerUpdateMp(player, "+", 30);
                                this.playerUpdateValue(player);
                            }
                        }

                        if (isEat) {
                            this.fruitList.splice(j, 1);
                        }
                    }
                }

                if (player.getSkillCount("能量护盾").count == 0) {
                    // 处理子弹碰撞
                    for (let j: number = 0; j < this.bulletList.length; j++) {
                        let bullet: lBullet = this.bulletList[j];

                        let collide2: Collide = {
                            x: bullet.x,
                            y: bullet.y,
                            width: bullet.width,
                            height: bullet.height
                        };

                        if (bullet.playerIds.indexOf(player.id) == -1) {

                            // 碰撞
                            if (this.collisionCircular(collide0, collide2)) {

                                bullet.playerIds.push(player.id);

                                // 不是同一队伍
                                if (bullet.teamId != player.teamId) {
                                    // console.log(player.name + " 被 " + this.getPlayer(attack.parentId).name + "攻击");

                                    this.playerUpdateHp(player, "-", bullet.attack);
                                    let otherPlayer: lPlayer = this.getPlayer(bullet.parentId);

                                    if (otherPlayer.getSkillCount("吸血术").count > 0) {
                                        let hpValue: number = Math.ceil(this.mul(bullet.attack, 0.25));
                                        this.playerUpdateHp(otherPlayer, "+", hpValue);
                                    }

                                    if (player.hp <= 0) {
                                        let skill0: lSkill = player.getSkill("护身石");
                                        if (skill0 != undefined) {
                                            if (skill0.interval == 0) {
                                                skill0.interval = skill0.intervalMax;
                                                player.hp = 100;
                                                let count: number = 1 * this.frameRate;
                                                if (player.getSkillCount("能量护盾").count < count) {
                                                    player.getSkillCount("能量护盾").count = count;
                                                }
                                            } else {
                                                this.playerBeat(player, otherPlayer, bullet);
                                            }
                                        } else {
                                            this.playerBeat(player, otherPlayer, bullet);
                                        }
                                    }

                                    if (otherPlayer.getSkillCount("穿透弹").count == 0) {
                                        // this.bulletList.splice(j, 1);
                                        if (bullet.count > 4) {
                                            bullet.count = 4;
                                        }
                                    }
                                } else {
                                    // 是同一队伍但是id不同 回复 10% 攻击值的血量
                                    if (bullet.parentId != player.id) {
                                        let hpValue: number = Math.ceil(this.mul(bullet.attack, 0.1));
                                        this.playerUpdateHp(player, "+", hpValue);
                                        this.playerUpdateValue(player);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * 更新果实数据
     */
    private updateFruit(): void {
        this.fruitTime++;
        if (this.fruitTime == this.fruitMaxTime) {
            this.fruitTime = 0;
            if (this.fruitList.length + 6 <= 120) {
                for (let i: number = 0; i < 6; i++) {
                    this.createRandomFruit();
                }
            }
        }

        // console.log("Fruit Count: " + this.fruitList.length);
    }

    /**
     * 更新时间数据
     */
    private updateTime(): void {
        this.timeCount += 1;
        if (this.timeCount == this.frameRate) {
            this.timeCount = 0;
            this.gameTime -= 1;
        }
    }

    /**
     * 是否碰撞 碰撞列表
     * @param obj 对象
     * @returns boolean
     */
    private isCollide(obj: Collide): boolean {
        for (let i: number = 0; i < this.collideList.length; i++) {
            let collide: Collide = this.collideList[i];
            let isCollide: boolean = this.collisionRectangular({ x: obj.x, y: obj.y, width: obj.width, height: obj.height }, collide);
            if (isCollide) {
                return true;
            }
        }
        return false;
    }

    /**
     * 碰撞 碰撞列表 处理
     * @param player 
     */
    private collidePhysics(player: lPlayer): void {
        for (let i: number = 0; i < this.collideList.length; i++) {
            let collide: Collide = this.collideList[i];
            let isCollide: boolean = this.collisionCircularWithRectangular({ x: player.x, y: player.y, width: player.width, height: player.height }, collide);
            if (isCollide) {
                let width1: number = this.mul(player.width, 0.5);
                let height1: number = this.mul(player.height, 0.5);
                let width2: number = this.mul(collide.width, 0.5);
                let height2: number = this.mul(collide.height, 0.5);

                let lerfX: number = this.sub(collide.x, width2);
                let rightX: number = this.add(collide.x, width2);
                let upY: number = this.add(collide.y, height2);
                let downY: number = this.sub(collide.y, height2);

                // x轴碰撞
                if (player.y < upY && player.y > downY) {
                    if (player.x < collide.x) {
                        player.x = this.sub3(collide.x, width1, width2);
                    }
                    if (player.x > collide.x) {
                        player.x = this.add3(collide.x, width1, width2);
                    }
                }

                // y轴碰撞
                if (player.x < rightX && player.x > lerfX) {
                    if (player.y < collide.y) {
                        player.y = this.sub3(collide.y, height1, height2);
                    }
                    if (player.y > collide.y) {
                        player.y = this.add3(collide.y, height1, height2);
                    }
                }

            }
        }
    }

    /**
     * 碰撞地图边界处理
     * @param obj 对象
     */
    private objCollisionMap(obj: any): void {
        let width: number = this.mul(obj.width, 0.5);
        let height: number = this.mul(obj.height, 0.5);

        if (this.add(obj.x, width) > this.mapX) {
            obj.x = this.sub(this.mapX, width);
        }
        if (this.sub(obj.x, width) < -this.mapX) {
            obj.x = this.add(-this.mapX, width);
        }
        if (this.add(obj.y, height) > this.mapY) {
            obj.y = this.sub(this.mapY, height);
        }
        if (this.sub(obj.y, height) < -this.mapY) {
            obj.y = this.add(-this.mapY, height);
        }
    }

    // 固定帧率执行
    private fixedUpdate(): void {
        this.actuatedFrame();
    }

    // 逻辑层更新
    update(dt: number) {
        // console.log("更新");
        this.dtNum += dt;

        if (this.dtNum >= this.fpsNum) {
            let count: number = Math.floor(this.dtNum / this.fpsNum);

            for (let i: number = 0; i < count; i++) {
                this.fixedUpdate();
            }

            this.dtNum -= count * this.fpsNum;
        }
    }

    /**
     * 获取唯一id
     * @returns id
     */
    private getId(): number {
        this.id++;
        let id: number = this.id;
        return id;
    }

    /**
     * 获取玩家对象
     * @param id 玩家id
     * @returns 玩家对象
     */
    private getPlayer(id: number): lPlayer {
        let index: number = -1;
        for (let i: number = 0; i < this.playerList.length; i++) {
            let player: lPlayer = this.playerList[i];
            if (player.id == id) {
                index = i;
                break;
            }
        }

        return this.playerList[index];
    }

    /**
     * 圆形与圆形碰撞检测
     * @param obj1 圆形1
     * @param obj2 圆形2
     * @returns 是否发生碰撞 boolean
     */
    private collisionCircular(obj1: Collide, obj2: Collide): boolean {

        let isCollision = false;

        let width1: number = this.mul(obj1.width, 0.5);
        let width2: number = this.mul(obj2.width, 0.5);
        let r: number = this.add(width1, width2);

        if (this.distance(obj1.x, obj1.y, obj2.x, obj2.y) < r) {
            isCollision = true;
        }

        return isCollision;
    }

    /**
     * 圆形与矩形碰撞检测
     * @param obj1 圆形
     * @param obj2 矩形
     * @returns 是否发生碰撞 boolean
     */
    private collisionCircularWithRectangular(obj1: Collide, obj2: Collide): boolean {

        let isCollision = false;

        let circle: Collide = obj1;
        let rect: Collide = obj2;
        let w: number = this.mul(rect.width, 0.5);
        let h: number = this.mul(rect.height, 0.5);
        let r: number = this.mul(circle.width, 0.5);
        let x: number = this.sub(circle.x, rect.x);
        let y: number = this.sub(circle.y, rect.y);
        let minX: number = Math.min(x, w);
        let maxX: number = Math.max(minX, -w);
        let minY: number = Math.min(y, h);
        let maxY: number = Math.max(minY, -h);

        if (this.add(this.mul(this.sub(maxX, x), this.sub(maxX, x)), this.mul(this.sub(maxY, y), this.sub(maxY, y))) < this.mul(r, r)) {
            isCollision = true;
        }

        return isCollision;
    }

    /**
     * 矩形与矩形碰撞检测
     * @param obj1 矩形1
     * @param obj2 矩形2
     * @returns 是否发生碰撞 boolean
     */
    private collisionRectangular(obj1: Collide, obj2: Collide): boolean {

        let isCollision = false;

        let width1: number = this.mul(obj1.width, 0.5);
        let height1: number = this.mul(obj1.height, 0.5);
        let width2: number = this.mul(obj2.width, 0.5);
        let height2: number = this.mul(obj2.height, 0.5);

        if (obj1.x > obj2.x && obj2.x < this.sub3(obj1.x, width1, width2)) {
        } else {
            if (obj1.x < obj2.x && obj2.x > this.add3(obj1.x, width1, width2)) {
            } else {
                if (obj1.y > obj2.y && obj2.y < this.sub3(obj1.y, height1, height2)) {
                } else {
                    if (obj1.y < obj2.y && obj2.y > this.add3(obj1.y, height1, height2)) {
                    } else {
                        isCollision = true;
                    }
                }
            }
        }

        return isCollision;
    }

    /**
     * 求向量
     * @param x x
     * @param y y
     * @returns // { x: vectorX, y: vecotrY }
     */
    private getVector(x: number, y: number): { x: number, y: number } {
        // let vectorX: number = y / (Math.sqrt(x * x + y * y));
        // let vecotrY: number = -x / (Math.sqrt(x * x + y * y));
        let vector: Vec2 = new Vec2(x, y);
        vector.normalize();
        let vectorX: number = Math.floor(vector.x * 1000) / 1000;
        let vecotrY: number = Math.floor(vector.y * 1000) / 1000;
        return { x: vectorX, y: vecotrY };
    }

    /**
     * 随机数
     * @param max 最大数
     * @returns 0 ~ max
     */
    private random(max: number): number {
        this.seed = (this.seed * 9301 + 49297) % 233280;
        let seed_: number = this.seed / 233280.0;
        let value: number = seed_ * max;
        return value;
    }

    /**
     * 指定范围随机数
     * @param min 最小数
     * @param max 最大数
     * @returns min ~ max
     */
    private randomRange(min: number, max: number) {
        let value: number = this.random(max - min) + min;
        return value;
    }

    /**
     * 两个坐标之间的距离
     * @param x1 x1坐标
     * @param y1 y1坐标
     * @param x2 x2坐标
     * @param y2 y2坐标
     * @returns 两点距离
     */
    private distance(x1: number, y1: number, x2: number, y2: number): number {
        return Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
    }

    /**
     * 两数相加
     * @param num1 数1
     * @param num2 数2
     * @returns num1 + num2
     */
    private add(num1: number, num2: number): number {
        return Math.floor(num1 * 1000 + num2 * 1000) / 1000;
    }

    /**
     * 三数相加
     * @param num1 数1
     * @param num2 数2
     * @param num3 数3
     * @returns num1 + num2 + num3
     */
    private add3(num1: number, num2: number, num3: number): number {
        return Math.floor(num1 * 1000 + num2 * 1000 + num3 * 1000) / 1000;
    }

    /**
     * 四数相加
     * @param num1 数1
     * @param num2 数2
     * @param num3 数3
     * @param num4 数4
     * @returns num1 + num2 + num3 + num4
     */
    private add4(num1: number, num2: number, num3: number, num4: number): number {
        return Math.floor(num1 * 1000 + num2 * 1000 + num3 * 1000 + num4 * 1000) / 1000;
    }

    /**
     * 两数相减
     * @param num1 数1
     * @param num2 数2
     * @returns num1 - num2
     */
    private sub(num1: number, num2: number): number {
        return Math.floor(num1 * 1000 - num2 * 1000) / 1000;
    }

    /**
     * 三数相减
     * @param num1 数1
     * @param num2 数2
     * @param num3 数3
     * @returns num1 - num2 - num3
     */
    private sub3(num1: number, num2: number, num3: number): number {
        return Math.floor(num1 * 1000 - num2 * 1000 - num3 * 1000) / 1000;
    }

    /**
     * 四数相减
     * @param num1 数1
     * @param num2 数2
     * @param num3 数3
     * @param num4 数4
     * @returns num1 - num2 - num3 - num4
     */
    private sub4(num1: number, num2: number, num3: number, num4: number): number {
        return Math.floor(num1 * 1000 - num2 * 1000 - num3 * 1000 - num4 * 1000) / 1000;
    }

    /**
     * 两数相乘
     * @param num1 数1
     * @param num2 数2
     * @returns num1 * num2
     */
    private mul(num1: number, num2: number): number {
        return Math.floor((num1 * 1000) * (num2 * 1000)) / 1000000;
    }

    /**
     * 两数相除
     * @param num1 数1
     * @param num2 数2
     * @returns num1 / num2
     */
    private div(num1: number, num2: number): number {
        return Math.floor((num1 * 1000) / (num2 * 1000));
    }

}
