
import { _decorator, Component, Node } from 'cc';
import { UIManager } from '../manager/UIManager';
const { ccclass, property } = _decorator;

/**
 * UI类
 */
@ccclass('UI')
export class UI extends Component {

    @property
    names: string = "";

    @property
    active: boolean = true;

    @property
    persistence: boolean = false;

    start() {
        if (this.persistence) {
            UIManager.instance.setPersistence(this.names, this.node);
        } else {
            UIManager.instance.setUI(this.names, this.node);
        }
        if (!this.active) {
            this.node.active = false;
        }
    }

    onDestroy() {
        if (!this.persistence) {
            UIManager.instance.removeUI(this.names);
        }
    }

}
