
import { _decorator, Component, Node } from 'cc';
import { Main } from '../scene/Main';
const { ccclass, property } = _decorator;

@ccclass('ButtonSkill')
export class ButtonSkill extends Component {

    public name_: string = "";

    onLoad() {
        this.node.on(Node.EventType.TOUCH_END, this.onTouchEnd, this);
    }

    private onTouchEnd(): void {
        Main.instance.showSkillText(this.name_);
    }

}
