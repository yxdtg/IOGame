
import { _decorator, Component, Node } from 'cc';
import { NetManager } from '../manager/NetManager';
const { ccclass, property } = _decorator;

@ccclass('UserPlayer')
export class UserPlayer extends Component {

    public id: number = -1;

    onLoad() {
        this.node.on(Node.EventType.TOUCH_END, this.onTouchEnd, this);
    }

    private onTouchEnd(): void {
        // console.log("抬起");
        NetManager.instance.ChooseUserImage(this.id);
    }

}
