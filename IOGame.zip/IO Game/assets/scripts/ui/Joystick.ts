
import { _decorator, Component, Node, Vec3, EventTouch, Vec2, UITransform } from 'cc';
import { NetManager } from '../manager/NetManager';
import { SceneManager } from '../manager/SceneManager';
import { UIManager } from '../manager/UIManager';
import { Game } from '../scene/Game';
const { ccclass, property } = _decorator;

@ccclass('Joystick')
export class Joystick extends Component {

    @property(Node)
    rocker: Node = null;

    @property(Node)
    chassis: Node = null;

    @property
    maxR: number = 0;

    @property
    type: number = 1;

    private dir: Vec3 = new Vec3(0, 0); // rocker向量
    private pos: Vec2 = new Vec2(0, 0);

    onLoad() {

    }

    start() {
        this.scheduleOnce(() => {
            this.init();
        }, 0)
    }

    private init(): void {
        let jType: number = 1;
        if (this.type == 1) {
            jType = NetManager.instance.joystickType;
        }

        // 初始坐标
        this.pos.x = this.node.position.x;
        this.pos.y = this.node.position.y;

        // 移动摇杆
        if (jType == 0) {
            let view: Node = UIManager.instance.getUI("ViewTouch");
            view.on(Node.EventType.TOUCH_START, this.onViewStart, this);
            view.on(Node.EventType.TOUCH_MOVE, this.onRockerDrag, this);
            view.on(Node.EventType.TOUCH_END, this.onRockerOver, this);
            view.on(Node.EventType.TOUCH_CANCEL, this.onRockerOver, this);
        }

        // 固定摇杆
        if (jType == 1) {
            this.rocker.on(Node.EventType.TOUCH_MOVE, this.onRockerDrag, this);
            this.rocker.on(Node.EventType.TOUCH_END, this.onRockerOver, this);
            this.rocker.on(Node.EventType.TOUCH_CANCEL, this.onRockerOver, this);
        }
    }

    // 移动摇杆位置更新
    private onViewStart(evet: EventTouch): void {
        let touchPos: Vec2 = evet.getUILocation();
        let pos: Vec3 = this.node.parent.getComponent(UITransform).convertToNodeSpaceAR(new Vec3(touchPos.x, touchPos.y));
        this.node.setPosition(pos);
    }

    // 摇杆拖拽
    private onRockerDrag(evet: EventTouch): void {
        if (UIManager.instance.getUI("PageReStart").active) {
            return;
        }
        let touchPos: Vec2 = evet.getUILocation();
        let pos: Vec3 = this.node.getComponent(UITransform).convertToNodeSpaceAR(new Vec3(touchPos.x, touchPos.y));
        let distance: number = Vec2.distance(new Vec2(0, 0), new Vec2(pos.x, pos.y));
        this.dir = pos.normalize();
        let rockerPos: Vec2 = new Vec2(0, 0);
        if (distance < this.maxR) {
            rockerPos.x = this.dir.x * distance;
            rockerPos.y = this.dir.y * distance;
        } else {
            rockerPos.x = this.dir.x * this.maxR;
            rockerPos.y = this.dir.y * this.maxR;
        }

        this.rocker.setPosition(rockerPos.x, rockerPos.y);
        let dx: number = Math.floor(this.dir.x * 1000) / 1000;
        let dy: number = Math.floor(this.dir.y * 1000) / 1000;

        if (this.type == 1) {
            Game.instance.addFrame({ cmd: "setVector", data: [NetManager.instance.uid_, dx, dy] });
        } else {
            Game.instance.playerAttack(dx, dy);
        }
    }

    // 摇杆拖拽结束
    public onRockerOver(): void {
        this.dir.x = 0;
        this.dir.y = 0;
        this.rocker.setPosition(0, 0);
        if (NetManager.instance.joystickType == 0) {
            this.node.setPosition(this.pos.x, this.pos.y);
        }
        if (this.type == 1) {
            Game.instance.addFrame({ cmd: "setVector", data: [NetManager.instance.uid_, 0, 0] });
        } else {
            Game.instance.playerStopAttack();
        }
    }

    /**
     * 移除摇杆事件监听
     */
    public offDrag(): void {
        this.rocker.setPosition(0, 0);
        if (this.dir != undefined) {
            this.dir.x = 0;
            this.dir.y = 0;
        }

        if (NetManager.instance.joystickType == 1) {
            this.rocker.off(Node.EventType.TOUCH_MOVE, this.onRockerDrag, this);
            this.rocker.off(Node.EventType.TOUCH_END, this.onRockerOver, this);
            this.rocker.off(Node.EventType.TOUCH_CANCEL, this.onRockerOver, this);
        } else {
            let view: Node = UIManager.instance.getUI("ViewTouch");
            view.off(Node.EventType.TOUCH_START, this.onViewStart, this);
            view.off(Node.EventType.TOUCH_MOVE, this.onRockerDrag, this);
            view.off(Node.EventType.TOUCH_END, this.onRockerOver, this);
            view.off(Node.EventType.TOUCH_CANCEL, this.onRockerOver, this);
        }
    }

}
