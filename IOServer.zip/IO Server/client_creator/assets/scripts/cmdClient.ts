export const enum cmd {
	/**
	 * ping测试
	 */
	connector_main_ping = "connector.main.ping",
}