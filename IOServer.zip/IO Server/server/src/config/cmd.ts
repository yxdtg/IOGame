export const enum cmd {
	/**
	 * ping测试
	 */
	connector_main_ping = 0,
	/**
	 * 登录
	 */
	connector_main_login = 1,
	/**
	 * 队组
	 */
	connector_main_group = 2,
	/**
	 * 匹配
	 */
	connector_main_match = 3,
	/**
	 * 帧数据
	 */
	connector_main_frame = 4,
	/**
	 * 房间
	 */
	connector_main_room = 5,
	/**
	 * 错误码
	 */
	connector_main_error = 6,
}