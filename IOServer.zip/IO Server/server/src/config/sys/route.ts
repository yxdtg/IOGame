export default [
    "connector.main.ping",  // ping测试
    "connector.main.login",  // 登录
    "connector.main.group", // 队组
    "connector.main.match", // 匹配
    "connector.main.frame", // 帧数据
    "connector.main.room", // 房间
    "connector.main.error", // 错误码
]