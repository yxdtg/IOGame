
import { connector, createApp, Session } from "mydog";
import { Lobby } from "./app/lobby";
import { getCpuUsage } from "./cpuUsage";
let app = createApp();

app.setConfig("connector", { "connector": connector.Ws, "clientOnCb": clientOnCb, "maxConnectionNum": 100, "clientOffCb": clientOffCb });
app.setConfig("encodeDecode", { "msgDecode": msgDecode, "msgEncode": msgEncode });
app.setConfig("logger", (type, level, msg) => {
    if (level === "warn" || level === "error") {
        console.log(msg);
    }
});
app.setConfig("rpc", { "interval": 33 });
app.setConfig("mydogList", () => {
    return [{ "title": "cpu", "value": getCpuUsage() }]
})

app.configure("connector", () => {
    let lobby: Lobby = new Lobby();
    app.set("Lobby", lobby);
})

app.start();

process.on("uncaughtException", function (err: any) {
    console.log(err)
});


function msgDecode(cmd: number, msg: Buffer): any {
    let msgStr = msg.toString();
    // console.log("↑ ", app.routeConfig[cmd], msgStr);
    return JSON.parse(msgStr);
}

function msgEncode(cmd: number, msg: any): Buffer {
    let msgStr = JSON.stringify(msg);
    // console.log(" ↓", app.routeConfig[cmd], msgStr);
    return Buffer.from(msgStr);
}


function clientOnCb(session: Session) {
    console.log("客户端加入");
}

function clientOffCb(session: Session) {
    console.log("客户端离开");
    // console.log(session.uid);
}
