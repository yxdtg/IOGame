import { app, Application, Session } from "mydog";
import { Lobby } from "../../../app/lobby";
import { Player } from "../../../app/player";
import { Room } from "../../../app/room";
import { cmd } from "../../../config/cmd";

let fs: any = require("fs");

enum LoginCode {
    Registration_No = 0,
    Registration_Ok = 1,
    Login_No = 2,
    Login_Ok = 3,
}

/**
 * 用户数据
 */
type userData = {
    /**
     * 账号
     */
    account: number,
    /**
     * 密码
     */
    password: string,
    /**
     * 等级
     */
    rank: number,
    /**
     * 经验
     */
    experience: number,
    /**
     * 金币
     */
    coin: number,
    /**
     * 宝石
     */
    gemstone: number,
    /**
     * 礼物次数
     */
    gift: number,
    /**
     * 上次登录时间
     */
    day: Day,
    /**
     * 角色列表
     */
    roles: any[],
    /**
     * 道具列表
     */
    items: any[],
};

type Day = {
    year: number,
    month: number,
    day: number,
};

type Gift = {
    type: number,
    value: number
};

export default class Handler {
    app: Application;
    lobby: Lobby;
    /**
     * 游戏版本
     */
    public gameVersion: number = 17;

    private giftList: { [id: number]: Gift } = {
        [0]: { type: 1, value: 10 },
        [1]: { type: 0, value: 80 },
        [2]: { type: 1, value: 6 },
        [3]: { type: 0, value: 50 },
        [4]: { type: 1, value: 8 },
        [5]: { type: 0, value: 30 },
        [6]: { type: 1, value: 2 },
        [7]: { type: 0, value: 100 },
    };

    constructor(app: Application) {
        this.app = app;
        this.lobby = this.app.get("Lobby");

        console.log("服务器启动, 版本: " + this.gameVersion);
    }

    // ping测试
    public ping(msg: { type: number, uid: number, data: any }, session: Session, next: Function): void {
        let type: number = msg.type;
        // 心跳检测
        if (type == 0) {
            let player: Player = this.lobby.getPlayer(msg.uid);
            if (player != undefined) {
                player.heartbeat = player.maxHeartbeat;
            }
        }
        // 版本检测
        if (type == 1) {
            let version: number = msg.data[0];
            if (version != this.gameVersion) {
                next({ type: type, data: [0] });
            } else {
                next({ type: type, data: [1] });
            }
        }
        // 每日好礼
        if (type == 2) {
            let giftId: number = Math.round(Math.random() * (Object.keys(this.giftList).length - 1));
            this.getGift(giftId, this.giftList[giftId], msg.uid);
        }

        // 退出登录
        if (type == 3) {
            let uid: number = msg.uid;
            this.lobby.removePlayer(uid);

            // 关闭客户端
            session.close();
        }

        // 技能更新
        if (type == 4) {
            let uid: number = msg.uid;
            let player: Player = this.lobby.getPlayer(uid);
            player.skills = msg.data;
            // console.log(player.skills);
        }
    }

    public getGift(giftId: number, gift: Gift, uid: number): void {
        fs.readFile("././data" + "/Y_" + uid + ".json", (err: Error, data: any) => {
            if (err) {
                console.log("读取文件错误", err);
                return;
            }
            console.log("读取文件成功");
            let datas: userData = JSON.parse(data.toString());
            if (datas.gift == 0) {
                // app.sendMsgByUid(cmd.connector_main_ping, { type: 2, data: [-1] }, [uid]);
                return;
            }

            app.sendMsgByUid(cmd.connector_main_ping, { type: 2, data: [giftId] }, [uid]);
            datas.gift -= 1;
            if (gift.type == 0) {
                datas.coin += gift.value;
            }
            if (gift.type == 1) {
                datas.gemstone += gift.value;
            }

            fs.writeFile("././data" + "/Y_" + uid + ".json", JSON.stringify(datas), (err: Error) => {
                if (err) {
                    console.log("写入文件错误", err);
                    return;
                }
                console.log("写入文件成功");
                app.sendMsgByUid(cmd.connector_main_ping, { type: 0, data: datas }, [uid]);
            })
        })
    }

    // 登录
    public login(msg: { type: number, data: any[] }, session: Session, next: Function): void {
        let type: number = msg.type;
        let data: any[] = msg.data;

        // 注册
        if (type == 0) {
            let account: number = data[0];
            let password: string = data[1];
            // console.log(data);

            let userData: userData = {
                account: account,
                password: password,
                rank: 1,
                experience: 0,
                coin: 0,
                gemstone: 0,
                gift: 1,
                day: { year: new Date().getFullYear(), month: new Date().getMonth(), day: new Date().getDate() },
                roles: [],
                items: []
            };

            this.runRegistration(JSON.stringify(userData), account, password, next, session);
            // this.createFile("./src/data", "Y_" + account + ".json", JSON.stringify(datas), next);
        }

        // 登录
        if (type == 1) {
            let name: string = data[0];
            let userId: number = data[1];
            let account: number = data[2];
            let password: string = data[3];

            this.runLogin(name, userId, account, password, next, session);
        }
    }

    // 队组
    public group(msg: { type: number, uid: number, groupId: number, removeId: number }, session: Session, next: Function): void {
        this.lobby.group(msg);
    }

    // 匹配
    public match(msg: { type: number, uid: number, groupId: number }, session: Session, next: Function): void {
        this.lobby.match(msg);
    }

    // 帧数据
    public frame(msg: { roomId: number, data: any }): void {
        this.lobby.frame(msg);
    }

    // 房间
    public room(msg: { type: number, uid: number, name: string, userId: number, roomId: number, frame: number }, session: Session, next: Function): void {
        let type: number = msg.type;
        let uid: number = msg.uid;
        let name: string = msg.name;
        let userId: number = msg.userId;
        let roomId: number = msg.roomId;
        let frame: number = msg.frame;

        console.log("房间");
        if (type == 0) {
            // 查询客户端是否存在，存在则断开
            let client: Session = app.getSession(uid);
            if (client != undefined) {
                client.close();
            }

            console.log("roomId: " + roomId);
            // 重连大厅
            if (roomId == -1) {
                // 创建玩家
                if (this.lobby.getPlayer(uid) == undefined) {
                    // 重新绑定uid
                    session.bind(uid);
                    this.lobby.createPlayer(uid, name, false, userId);
                    let player: Player = this.lobby.getPlayer(uid);
                    app.sendMsgByUid(cmd.connector_main_room, { type: 0, data: player }, [uid]);
                    console.log("重连大厅");
                } else {
                    next({ type: 3 });
                }

            } else {
                // 重连房间 未完善 2022年4月2日22:36:30 明天继续 拜拜 晚安
                // 完成 2022年4月3日11:35:45
                console.log("重连房间");
                let room: Room = this.lobby.getRoom(roomId);
                if (room != undefined) {
                    // 重新绑定uid
                    session.bind(uid);
                    room.reconnect(uid, frame);
                } else {
                    // 房间不存在
                    // 创建玩家
                    if (this.lobby.getPlayer(uid) == undefined) {
                        // 重新绑定uid
                        session.bind(uid);
                        this.lobby.createPlayer(uid, name, false, userId);
                        let player: Player = this.lobby.getPlayer(uid);
                        app.sendMsgByUid(cmd.connector_main_room, { type: 2, data: player }, [uid]);
                        console.log("重连大厅");
                    } else {
                        next({ type: 3 });
                    }
                }
            }

        }
    }

    // 注册
    public runRegistration(data: string, account: number, password: string, next: Function, session: Session): void {
        fs.access("././data" + "/Y_" + account + ".json", (err: Error) => {
            console.log(err);
            if (err) {
                console.log("文件不存在", err);

                fs.writeFile("././data" + "/Y_" + account + ".json", data, (err: Error) => {
                    if (err) {
                        console.log("创建文件错误", err);
                        next({ type: LoginCode.Registration_No, data: 0 });
                        return;
                    }
                    console.log("创建文件成功");
                    next({ type: LoginCode.Registration_Ok, data: 0 });
                })

                return;
            }
            console.log("文件存在");
            next({ type: 0, data: 1 });
        })
    }

    // 登录
    public runLogin(name: string, userId: number, account: number, password: string, next: Function, session: Session): void {
        fs.readFile("././data" + "/Y_" + account + ".json", (err: Error, data: any) => {
            if (err) {
                console.log("读取文件错误", err);
                next({ type: LoginCode.Login_No, data: 0 });
                return;
            }
            console.log("读取文件成功");
            let datas: userData = JSON.parse(data.toString());

            if (datas.password == password) {

                if (app.getSession(account) != undefined) {
                    console.log("uid已绑定...");
                    // next({ type: LoginCode.Login_Ok, data: 0 });
                    next({ type: 4, data: [account, 0] });
                    return;
                }

                console.log("登录成功");
                session.bind(account);

                // 当前日期
                let day: Day = { year: new Date().getFullYear(), month: new Date().getMonth(), day: new Date().getDate() };

                // 上次登录日期
                let oldDay: Day = datas.day;

                // 是否是新的一天
                let isNew = false;

                if (oldDay.year != day.year) {
                    isNew = true;
                }
                if (oldDay.month != day.month) {
                    isNew = true;
                }
                if (oldDay.day != day.day) {
                    isNew = true;
                }

                // 更新逻辑
                if (isNew) {
                    datas.day = day;
                    if (datas.gift == 0) {
                        datas.gift = 1;
                    }
                }
                // console.log(day);
                // console.log(isNew);
                // console.log(datas);

                // 更新用户数据
                fs.writeFile("././data" + "/Y_" + account + ".json", JSON.stringify(datas), (err: Error) => {
                    if (err) {
                        console.log("写入文件错误", err);
                        return;
                    }
                    console.log("写入文件成功");

                    let roomId: number = this.lobby.login(datas, name, userId);

                    if (roomId != -1) {

                        this.lobby.getPlayer(account).connectState = false;
                        next({ type: 3, data: [account, datas, name, userId], roomId: roomId });

                        setTimeout(() => {
                            let room: Room = this.lobby.getRoom(roomId);
                            room.reconnect(account, 0);
                        }, 1000);
                    } else {
                        next({ type: 3, data: [account, datas, name, userId] });
                    }
                })

            } else {
                next({ type: LoginCode.Login_No, data: 1 });
            }
        })
    }

    /**
     * 创建文件(异步)
     * @param path 文件路径
     * @param name 文件名称
     * @param data 文件数据
     */
    public createFile(path: string, name: string, data: string, next: Function): void {
        fs.writeFile(path + "/" + name, data, (err: Error) => {
            if (err) {
                console.log("创建文件错误", err);
                next({ type: 0, data: 0 });
                return;
            }
            console.log("创建文件成功");
            next({ type: 1, data: 0 });
        })
    }

    /**
     * 读取文件(异步)
     * @param path 文件路径
     * @returns 文件数据
     */
    public readFile(path: string, password: string, next: Function, next1: Function, session: Session): void {
        // let data: string = fs.readFile(path);
        fs.readFile(path, (err: Error, data: any) => {
            if (err) {
                console.log("读取文件错误", err);
                next({ type: 2, data: 0 }, next1, session);
                return;
            }
            console.log("读取文件成功");
            // console.log(data.toString());
            let datas: any = JSON.parse(data.toString());
            if (datas.password == password) {
                next({ type: 3, data: datas }, next1, session);
            } else {
                next({ type: 2, data: 0 }, next1, session);
            }
        })
    }

    /**
     * 写入文件(异步)
     * @param path 文件路径
     * @param data 文件数据
     */
    public writeFile(path: string, data: string): void {
        fs.writeFile(path, data, (err: Error) => {
            if (err) {
                console.log("写入文件错误", err);
                return;
            }
            console.log("写入文件成功");
        })
    }

}