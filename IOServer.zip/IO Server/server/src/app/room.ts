import { app } from "mydog";
import { cmd } from "../config/cmd";
import { Lobby } from "./lobby";
import { Player } from "./player";

/**
 * 帧数据
 */
type Frame = {
    cmd: string,
    data: any[]
};

/**
 * 房间类
 */
export class Room {

    /**
     * 房间id
     */
    public id: number = -1;

    /**
     * 房间玩家列表
     */
    public playerList: Player[] = [];

    private seed: number = 999; // 随机数种子
    private frameList: Frame[][] = []; // 帧数据列表
    private frameIndex: number = 0; // 帧索引
    private fps: number = 15; // 帧率
    private frameRate: number = 1000 / this.fps; // 帧速率

    private gameTime: number = (6 * this.fps * 60) + 5; // 游戏时间

    private nameList: string[] = [
        "朝歌晚酒",
        "都怪时光太动听",
        "时光凉,春衫薄",
        "笑我孤陋",
        "水墨青花",
        "っAngel′幻雪づ",
        "梦中有梦",
        "- 失梦者",
        "江山如画怎及你",
        "浅梦墨汐°",
        "❀笑靥如花ヅ",
        "且听风吟",
        "挽梦忆笙歌",
        "沫笙ゅ",
        "清风墨竹",
        "樱の舞",
        "半夏倾城",
        "南栀倾寒°",
        "入画浅相思",
        "旧雪烹茶",
        "若人生〆只如初见",
        "forever 浅笑°",
        "柚子泡芙",
        "醋拌柠檬",
        "初恋栀子花",
        "南海凝心",
        "暖风吹怀",
        "青桔味的风",
        "北街落初雨",
        "倾听夏末",
        "嗷哩个嗷~",
        "雪蕊幽香",
        "下一次微笑",
        "孤者何惧",
        "我心永恒",
        "永恒之心",
        "一步两步散步",
        "以风予你",
        "念于红尘",
        "番茄炒蛋",
        "黄焖鸡米饭",
        "辣子鸡",
        "浅花芯",
        "兮里怡",
        "殷九歌",
        "挽木琴",
        "清风叹",
        "夏日薄雪",
        "江南春失忆梦",
        "晚风听街雨",
        "你的眼里是星辰",
        "伴生梦",
        "蛋炒饭",
        "青椒炒蛋",
        "不想则不念",
        "念念不忘",
        "像雾像雨又像风",
        "小新要、小心",
        "心点时间到了",
        "你回来了~",
        "我回来了~"
    ];

    constructor(id: number, players: Player[]) {
        this.id = id;
        this.playerList = players;

        this.init();
    }

    // 初始化
    public init(): void {

        // 目标 4 v 4 v 4 并且分配昵称
        let teams: { [id: number]: Player[] } = {};

        for (let i: number = 0; i < this.playerList.length; i++) {
            let player: Player = this.playerList[i];
            // 是机器人则分配昵称
            if (player.isRobot) {
                player.name = this.getName();
            }
            if (teams[player.groupId] == undefined) {
                teams[player.groupId] = [player];
            } else {
                teams[player.groupId].push(player);
            }
        }

        // console.log(teams);

        let teamList: { [id: number]: Player[] } = {};

        teamList[1] = [];
        teamList[2] = [];
        teamList[3] = [];

        let teamIds: number[] = [1, 2, 3];
        teamIds = this.randomSort(teamIds);

        // console.log("teamIds-------------");
        // console.log(teamIds);

        for (let teamId in teams) {
            let team: Player[] = teams[teamId];

            if (team.length == 4) {
                for (let i: number = 1; i < 4; i++) {
                    if (teamList[i].length == 0) {
                        teamList[i] = team;
                        i = 4;
                    }
                }
            }

            if (team.length == 3) {
                for (let i: number = 1; i < 4; i++) {
                    if (teamList[i].length == 0) {
                        teamList[i] = team;
                        i = 4;
                    }
                }
            }

            if (team.length == 2) {
                for (let i: number = 1; i < 4; i++) {
                    if (teamList[i].length == 0) {
                        teamList[i] = team;
                        i = 4;
                        break;
                    }
                    if (teamList[i].length == 2) {
                        teamList[i].push(team[0]);
                        teamList[i].push(team[1]);
                        i = 4;
                    }
                }
            }

            if (team.length == 1) {
                for (let i: number = 1; i < 4; i++) {
                    if (teamList[i].length == 0) {
                        teamList[i] = team;
                        i = 4;
                        break;
                    }
                    if (teamList[i].length == 3) {
                        teamList[i].push(team[0]);
                        i = 4;
                        break;
                    }
                    if (teamList[i].length == 2) {
                        teamList[i].push(team[0]);
                        i = 4;
                        break;
                    }
                    if (teamList[i].length == 1) {
                        teamList[i].push(team[0]);
                        i = 4;
                        break;
                    }
                }
            }

        }

        // console.log(teamList);

        // console.log("分配队伍------------->");

        // 打印
        for (let id in teamList) {
            let team: Player[] = teamList[id];
            let names: string[] = [];
            for (let i: number = 0; i < team.length; i++) {
                names.push(team[i].name);
            }
            // console.log("队伍: " + id, names);
        }

        // 分配队伍id
        let count: number = 0;
        for (let teamId in teamList) {
            let team: Player[] = teamList[teamId];
            for (let i: number = 0; i < team.length; i++) {
                let player: Player = team[i];
                player.teamId = teamIds[count];
            }
            count++;
        }

        this.seed = Math.floor(Math.random() * 100000000);

        this.frameList.push([]);

        let frame: Frame = { cmd: "setSeed", data: [this.seed] };
        this.frameList[this.frameIndex].push(frame);

        for (let i: number = 0; i < this.playerList.length; i++) {
            let player: Player = this.playerList[i];
            player.roomId = this.id;
            let frame: Frame = { cmd: "createPlayer", data: [player.id, player.name, player.isRobot, player.userId, player.teamId, player.skills] };
            this.frameList[this.frameIndex].push(frame);
        }

        console.log("游戏开始: " + this.id);

        setTimeout(this.update.bind(this), 500);
    }

    /**
     * 获取唯一昵称
     * @returns 昵称
     */
    private getName(): string {
        let name: string = "";
        let index: number = Math.round(Math.random() * (this.nameList.length - 1));
        name = this.nameList[index];
        this.nameList.splice(index, 1);

        return name;
    }

    private randomSort(arr: any[]): any[] {
        let index,
            randomIndex,
            temp,
            len = arr.length;

        for (index = 0; index < len; index++) {
            randomIndex = Math.floor(Math.random() * (len - index)) + index;

            temp = arr[index];
            arr[index] = arr[randomIndex];
            arr[randomIndex] = temp;
        }

        return arr;
    }

    // 更新房间循环
    public update(): void {

        if (this.gameTime == 0) {
            return;
        }

        setTimeout(this.update.bind(this), this.frameRate);

        this.sendFrame();
        this.updateTime();
    }

    /**
     * 加入帧数据
     * @param frameData 帧数据包
     */
    public addFrame(frameData: Frame[]): void {
        for (let i: number = 0; i < frameData.length; i++) {
            this.frameList[this.frameIndex].push(frameData[i]);
        }
    }

    /**
     * 断线重连
     * @param uid 玩家uid
     * @param frameIndex 玩家帧索引
     */
    public reconnect(uid: number, frameIndex: number): void {
        let player: Player = this.getPlayer(uid);
        player.connectState = true;
        player.frameIndex = frameIndex;
        player.isReconnect = true;
    }

    /**
     * 发送帧数据
     */
    public sendFrame(): void {
        let uidList: number[] = [];
        let reconnectList: number[] = [];

        for (let i: number = 0; i < this.playerList.length; i++) {
            let player: Player = this.playerList[i];
            if (!player.isRobot) {
                if (!player.isReconnect) {
                    if (player.connectState) {
                        uidList.push(player.id);
                    }
                } else {
                    reconnectList.push(player.id);
                }
            }
        }

        if (reconnectList.length > 0) {
            console.log(reconnectList);
            for (let i: number = 0; i < reconnectList.length; i++) {
                let frameData: Frame[][] = [];

                let player: Player = this.getPlayer(reconnectList[i]);
                console.log(player);
                for (let j: number = player.frameIndex; j < this.frameList.length; j++) {
                    frameData.push(this.frameList[j]);
                }

                app.sendMsgByUid(cmd.connector_main_room, { type: 1, data: frameData }, [player.id]);

                player.isReconnect = false;
            }
        }
        if (uidList.length > 0) {
            let frameData: Frame[] = this.frameList[this.frameIndex];
            app.sendMsgByUid(cmd.connector_main_frame, { type: 0, data: frameData }, uidList);
        }

        this.frameList.push([]);
        this.frameIndex++;
    }

    private updateTime(): void {
        this.gameTime -= 1;
        if (this.gameTime == 0) {
            console.log("游戏结束: " + this.id);

            let lobby: Lobby = app.get("Lobby");

            // 移除机器人
            let uids: number[] = [];
            for (let i: number = 0; i < this.playerList.length; i++) {
                let player: Player = this.playerList[i];
                if (player.isRobot) {
                    uids.push(player.id);
                } else {
                    player.init();
                }
            }
            for (let i: number = 0; i < uids.length; i++) {
                let uid: number = uids[i];
                delete lobby.playerList[uid];
            }

            // 房间销毁
            delete lobby.roomList[this.id];
        }
    }

    /**
     * 获取玩家对象
     * @param uid 玩家uid
     * @returns 玩家对象
     */
    private getPlayer(uid: number): Player {
        let index: number = -1;
        for (let i: number = 0; i < this.playerList.length; i++) {
            let player: Player = this.playerList[i];
            if (player.id == uid) {
                index = i;
                break;
            }
        }

        return this.playerList[index];
    }

}