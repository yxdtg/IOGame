import { app, Session } from "mydog";
import { cmd } from "../config/cmd";
import { Group } from "./group";
import { Match } from "./match";
import { Player } from "./player";
import { Room } from "./room";

/**
 * 大厅类
 */
export class Lobby {

    constructor() {
        console.log("大厅启动");

        setTimeout(this.update.bind(this), 1000);
    }

    private roomId: number = 0; // 房间id
    private groupId: number = 0; // 队组id
    private matchId: number = 0; // 匹配id
    private playerId: number = 0; // 玩家id

    public roomList: { [id: number]: Room } = {}; // 房间集合
    public groupList: { [id: number]: Group } = {}; // 队组集合
    public matchList: { [id: number]: Match } = {}; // 匹配集合
    public playerList: { [id: number]: Player } = {}; // 玩家集合

    /**
     * 登录
     * @param name 昵称
     */
    public login(data: any, name: string, userId: number): number {
        // let id: number = this.getPlayerId();
        // let isLogin: boolean = true;
        let roomId: number = -1;
        let player: Player = this.getPlayer(data.account);
        if (player == undefined) {
            this.createPlayer(data.account, name, false, userId);
        } else {
            if (player.roomId != -1) {
                roomId = player.roomId;
            }
        }

        return roomId;
        // next({ type: 3, data: [id, data] });
        // return id;
    }

    /**
     * 队组
     * @param msg 数据
     */
    public group(msg: { type: number, uid: number, groupId: number, removeId: number }): void {
        let type: number = msg.type;
        let uid: number = msg.uid;
        let groupId: number = msg.groupId;
        let removeId: number = msg.removeId;

        // 创建队组
        if (type == 0) {
            this.createGroup(uid);
        }
        // 加入队组
        if (type == 1) {
            this.joinGroup(uid, groupId);
        }
        // 离开队组
        if (type == 2) {
            this.leaveGroup(uid, groupId);
        }
        // 队组中移除指定玩家
        if (type == 3) {
            // console.log("队组中移除指定玩家");
            // console.log(msg);
            this.removeGroup(uid, groupId, removeId);
        }
    }

    /**
     * 匹配
     * @param msg 数据
     */
    public match(msg: { type: number, uid: number, groupId: number }): void {
        let type: number = msg.type;
        let uid: number = msg.uid;
        let groupId: number = msg.groupId;

        // 开始匹配
        if (type == 0) {
            let group: Group = this.getGroup(groupId);
            if (group != undefined) {
                // 不在匹配中
                if (!group.isMatch) {
                    if (group.playerList[0].id == uid) {
                        group.isMatch = true;
                        console.log("开始匹配");
                        // 匹配列队是否为空
                        if (Object.keys(this.matchList).length == 0) {
                            // 创建一个匹配队列
                            this.createMatch(group.playerList);
                            console.log("创建一个匹配队列");
                        } else {
                            // 尝试加入一个匹配队列
                            for (let id in this.matchList) {
                                let match: Match = this.matchList[id];
                                let matchCount: number = match.playerList.length + group.playerList.length;
                                if (matchCount <= match.matchCount) {
                                    match.addGroup(group.playerList);
                                    let uids: number[] = [];
                                    for (let i: number = 0; i < group.playerList.length; i++) {
                                        let player: Player = group.playerList[i];
                                        uids.push(player.id);
                                    }
                                    app.sendMsgByUid(cmd.connector_main_match, { type: 0, data: 0 }, uids);
                                    console.log("加入匹配队列");
                                    return;
                                }
                            }

                            // 没有符合条件的匹配队列，创建匹配
                            this.createMatch(group.playerList);
                            console.log("没有符合条件的匹配队列，创建匹配");
                        }
                    } else {
                        app.sendMsgByUid(cmd.connector_main_error, 2, [uid]);
                    }
                }
            }
        }
        // 取消匹配
        if (type == 1) {
            let group: Group = this.getGroup(groupId);
            if (group != undefined) {
                let player: Player = this.getPlayer(uid);
                let index: number = group.playerList.indexOf(player);
                if (index != -1) {
                    console.log("取消匹配");
                    let match: Match = this.getMatch(player.matchId);
                    match.removeGroup(group.playerList);

                    let uids: number[] = [];
                    for (let i: number = 0; i < group.playerList.length; i++) {
                        let player: Player = group.playerList[i];
                        uids.push(player.id);
                    }
                    app.sendMsgByUid(cmd.connector_main_match, { type: 1, data: 0 }, uids);
                }
            }
        }
    }

    /**
     * 帧数据
     * @param msg 数据
     * @returns 无
     */
    public frame(msg: { roomId: number, data: any }): void {
        let roomId: number = msg.roomId;
        let data: any = msg.data;
        // console.log(msg);

        let room: Room = this.getRoom(roomId);

        if (room == undefined) {
            return;
        }
        // 新增帧数据
        room.addFrame(data);
    }

    /**
     * 更新客户端队组数据
     * @param groupId 队组id
     * @returns 无
     */
    public updateGroup(groupId: number): void {
        let group: Group = this.getGroup(groupId);
        if (group == undefined) {
            return;
        }
        let uids: number[] = [];
        let players: Player[] = group.playerList;
        for (let i: number = 0; i < players.length; i++) {
            uids.push(players[i].id);
        }
        app.sendMsgByUid(cmd.connector_main_group, { type: 4, data: [group.id, group.playerList] }, uids);
    }

    /**
     * 创建房间
     * @param players 玩家列表
     * @return 房间id
     */
    public createRoom(players: Player[]): number {
        let id: number = this.getRoomId();
        let room: Room = new Room(id, players);
        this.roomList[id] = room;
        return id;
    }

    /**
     * 创建队组
     * @param uid 玩家id
     */
    public createGroup(uid: number): void {
        let player: Player = this.getPlayer(uid);
        let id: number = this.getGroupId();
        let group: Group = new Group(id);
        group.addPlayer(player);
        this.groupList[id] = group;
        app.sendMsgByUid(cmd.connector_main_group, { type: 0, data: 0 }, [player.id]);
        this.updateGroup(group.id);
    }

    /**
     * 加入队组
     * @param uid 玩家id
     * @param groupId 队组id
     */
    public joinGroup(uid: number, groupId: number): void {
        let player: Player = this.getPlayer(uid);
        let group: Group = this.getGroup(groupId);
        if (group == undefined) {
            app.sendMsgByUid(cmd.connector_main_error, 0, [uid]);
            return;
        }
        if (!group.isJoin()) {
            app.sendMsgByUid(cmd.connector_main_error, 0, [uid]);
            return;
        }
        // if (group.playerList[0].isRobot) {
        //     console.log("队伍不存在!");
        //     return;
        // }
        group.addPlayer(player);
        app.sendMsgByUid(cmd.connector_main_group, { type: 1, data: 0 }, [player.id]);
        this.updateGroup(group.id);
    }

    /**
     * 离开队组
     * @param uid 玩家id
     * @param groupId 队组id
     */
    public leaveGroup(uid: number, groupId: number): void {
        let player: Player = this.getPlayer(uid);
        let group: Group = this.getGroup(groupId);
        if (group == undefined) {
            return;
        }
        if (!group.isLeave()) {
            app.sendMsgByUid(cmd.connector_main_error, 1, [uid]);
            return;
        }
        group.removePlayer(player);
        app.sendMsgByUid(cmd.connector_main_group, { type: 2, data: 0 }, [player.id]);
        this.updateGroup(group.id);
    }

    /**
     * 移除队组中的指定玩家
     * @param uid 队长 玩家id
     * @param groupId 队组id
     * @param removeId 被移除玩家在队组中的索引
     */
    public removeGroup(uid: number, groupId: number, removeId: number): void {
        let player: Player = this.getPlayer(uid);
        let group: Group = this.getGroup(groupId);
        if (group == undefined) {
            return;
        }
        // 不是队长?
        if (group.playerList[0] != player) {
            // console.log("不是队长");
            app.sendMsgByUid(cmd.connector_main_error, 2, [uid]);
            return;
        }
        // 不可以离开?
        if (!group.isLeave()) {
            app.sendMsgByUid(cmd.connector_main_error, 1, [uid]);
            return;
        }
        let removePlayer: Player = group.playerList[removeId];
        // 玩家不存在?
        if (removePlayer == undefined) {
            return;
        }
        group.removePlayer(removePlayer);
        app.sendMsgByUid(cmd.connector_main_group, { type: 3, data: 0 }, [removePlayer.id]);
        this.updateGroup(group.id);
    }

    /**
     * 创建匹配
     * @param id 匹配id
     * @param players 玩家列表
     */
    public createMatch(players: Player[]): void {
        let id: number = this.getMatchId();
        let match: Match = new Match(id);
        match.addGroup(players);
        this.matchList[id] = match;

        let uids: number[] = [];
        for (let i: number = 0; i < players.length; i++) {
            let player: Player = players[i];
            uids.push(player.id);
        }
        app.sendMsgByUid(cmd.connector_main_match, { type: 0, data: 0 }, uids);
    }

    /**
     * 创建玩家
     * @param id id
     * @param name 昵称
     */
    public createPlayer(id: number, name: string, isRobot: boolean, userId: number): void {
        let player: Player = new Player(id, name, isRobot, userId);
        this.playerList[id] = player;
    }

    /**
     * 获取房间唯一id
     * @returns 唯一id
     */
    public getRoomId(): number {
        this.roomId++;
        let id: number = this.roomId;
        return id;
    }

    /**
     * 获取队组唯一id
     * @returns 唯一id
     */
    public getGroupId(): number {
        this.groupId++;
        let id: number = this.groupId;
        return id;
    }

    /**
     * 获取匹配唯一id
     * @returns 唯一id
     */
    public getMatchId(): number {
        this.matchId++;
        let id: number = this.matchId;
        return id;
    }

    /**
     * 获取玩家唯一id
     * @returns 唯一id
     */
    public getPlayerId(): number {
        this.playerId++;
        let id: number = this.playerId;
        return id;
    }

    /**
     * 获取房间对象
     * @param id 房间id
     * @returns 房间对象
     */
    public getRoom(id: number): Room {
        return this.roomList[id];
    }

    /**
     * 获取队组对象
     * @param id 队组id
     * @returns 队组对象
     */
    public getGroup(id: number): Group {
        return this.groupList[id];
    }

    /**
     * 获取匹配对象
     * @param id 匹配id
     * @returns 匹配对象
     */
    public getMatch(id: number): Match {
        return this.matchList[id];
    }

    /**
     * 获取玩家对象
     * @param id 玩家id
     * @returns 玩家对象
     */
    public getPlayer(id: number): Player {
        return this.playerList[id];
    }

    /**
     * 更新循环
     */
    public update(): void {
        setTimeout(this.update.bind(this), 1000);

        this.updateAIMatch();

        this.updateMatch();

        this.updateHeartbeat();

        console.log("玩家数量: " + Object.keys(this.playerList).length + ", " + "队组数量: " + Object.keys(this.groupList).length + ", " + "匹配数量: " + Object.keys(this.matchList).length + ", " + "房间数量: " + Object.keys(this.roomList).length);
    }

    /**
     * 更新匹配循环
     */
    public updateMatch(): void {
        let removeList: number[] = [];
        for (let id in this.matchList) {
            let match: Match = this.matchList[id];
            if (match.isMatch()) {
                // console.log("匹配成功, matchId: " + match.id);

                let uids: number[] = [];
                for (let i: number = 0; i < match.playerList.length; i++) {
                    let player: Player = match.playerList[i];
                    if (!player.isRobot) {
                        uids.push(player.id);
                    }
                }

                let roomId: number = this.createRoom(match.playerList);

                app.sendMsgByUid(cmd.connector_main_match, { type: 2, data: { roomId: roomId } }, uids);

                removeList.push(match.id);
            }
        }

        // 移除匹配成功的匹配列队 以及 队组列队
        for (let i: number = 0; i < removeList.length; i++) {
            let id: number = removeList[i];
            let match: Match = this.matchList[id];
            let groupIds: number[] = [];
            for (let j: number = 0; j < match.playerList.length; j++) {
                let groupId: number = match.playerList[j].groupId;
                if (groupIds.indexOf(groupId) == -1) {
                    groupIds.push(groupId);
                }
            }
            for (let j: number = 0; j < groupIds.length; j++) {
                let id: number = groupIds[j];
                delete this.groupList[id];
            }
            delete this.matchList[id];
        }
    }

    /**
     * 更新机器人匹配循环
     */
    public updateAIMatch(): void {
        for (let id in this.matchList) {
            let match: Match = this.matchList[id];
            if (!match.isMatch()) {
                let id: number = this.getPlayerId();
                this.createPlayer(id, "ai_" + id, true, Math.round(Math.random() * 2));
                this.createGroup(id);
                let player: Player = this.getPlayer(id);
                match.addGroup([player]);
            }
        }
    }

    /**
     * 更新玩家心跳循环
     */
    public updateHeartbeat(): void {

        let playerIds: number[] = [];

        for (let id in this.playerList) {
            let player: Player = this.playerList[id];
            if (!player.isRobot && player.connectState) {
                player.heartbeat--;
                // console.log(player.name + "/heartbeat: " + player.heartbeat);
                // 心跳为0
                if (player.heartbeat == 0) {
                    if (player.roomId != -1) {
                        player.connectState = false;
                    }
                    playerIds.push(player.id);
                }
            }
        }

        // 移除
        for (let i: number = 0; i < playerIds.length; i++) {
            // 关闭连接
            let id: number = playerIds[i];

            let session: Session = app.getSession(id);
            if (session != null) {
                session.close();
            }

            // 移除队组中的玩家
            let player: Player = this.getPlayer(id);
            let groupId: number = player.groupId;
            let group: Group = this.getGroup(player.groupId);
            if (group != undefined) {
                group.removePlayer(player);
                this.updateGroup(groupId);
            }

            // 移除匹配中的玩家
            let matchId: number = player.matchId;
            let match: Match = this.getMatch(matchId);
            if (match != undefined) {
                match.removeGroup([player]);
            }

            // 移除玩家
            if (player.connectState) {
                delete this.playerList[id];
            }
        }
    }

    public removePlayer(uid: number): void {
        let player: Player = this.getPlayer(uid);

        if (player.groupId != -1) {
            let groupId: number = player.groupId;
            let group: Group = this.getGroup(player.groupId);
            if (group != undefined) {
                group.removePlayer(player);
                this.updateGroup(groupId);
            }
        }
        if (player.matchId != -1) {
            let matchId: number = player.matchId;
            let match: Match = this.getMatch(matchId);
            if (match != undefined) {
                match.removeGroup([player]);
            }
        }

        delete this.playerList[uid];
    }

}